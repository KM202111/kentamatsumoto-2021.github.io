//
//  AdvPeripheralCell.swift
//  AbilityTrainer
//
//  Created by hoehoe on 2019/09/09.
//  Copyright © 2019 chocbanana. All rights reserved.
//

import UIKit

class AdvPeripheralCell: UITableViewCell {

    @IBOutlet weak var lbl_name:UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
