//
//  BTManager.swift
//
//
//  Created by hoehoe on 2018/06/10.
//  Copyright © 2017年 chocbanana. All rights reserved.
//

import CoreBluetooth


@objc protocol BT_ManagerDelegate {

    func foundPeripheralDelegate(btPeripheral: BT_Peripheral)
    func lostPeripheralDelegate()
}

class BTManager: NSObject, CBCentralManagerDelegate, CBPeripheralDelegate
{
    
    static let shared:BTManager = BTManager()
    
    let serviceUUIDs:Array<CBUUID>? = [ CBUUID.init(string: "B8820001-95D7-4DD2-B5B3-07385E5E821F"), ]
    
    var manager:CBCentralManager! = nil
    var btPeripheral:BT_Peripheral! = nil

    weak var delegate:BT_ManagerDelegate?
    
    private override init() {
        super.init()
        manager = CBCentralManager(delegate: self, queue: nil)
    }
    
    func connect(peripheral :CBPeripheral){
         btPeripheral = BT_Peripheral()
         btPeripheral.peripheral = peripheral
         btPeripheral.setup()
        
         manager.connect(peripheral, options: nil)
         manager.stopScan()

     }
    
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        switch  central.state {
        case .poweredOn:
            start()
            break
        case .poweredOff:
            stop()
            break
        case .unauthorized:
            break
        default:
            break
        }
    }
    
    private func start(){
        
        
        manager.scanForPeripherals(withServices: serviceUUIDs, options: nil) //[advUUID]
        print("start scan")
    }
    
    private func stop(){
        
        if manager.isScanning == true {
            manager.stopScan()
        }

    }
    
    
    func centralManager(_ central: CBCentralManager, didFailToConnect peripheral: CBPeripheral, error: Error?) {
        self.delegate?.lostPeripheralDelegate()
    }
    
    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        print("didConnect")
        
        self.btPeripheral.peripheral.discoverServices(serviceUUIDs)
        self.delegate?.foundPeripheralDelegate(btPeripheral: self.btPeripheral)
    }
    
    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {

        start()

    }
    
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber) {

        btPeripheral = BT_Peripheral()
        btPeripheral.peripheral = peripheral
        btPeripheral.setup()
        
        //print(advertisementData)
        
        self.manager.connect(peripheral, options: nil)
        
        print("didDiscover")
    
    }

}

