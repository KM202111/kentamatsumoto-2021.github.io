//
//  BT_Message.swift
//  SC_Box
//
//  Created by hoehoe on 2021/09/13.
//  Copyright © 2021 chocbanana. All rights reserved.
//

import Foundation

class BT_Message {
    
    var mode: UInt8 = 0
    var type: UInt8 = 0
    
    init (mode: UInt8, type: UInt8) {
        self.mode = mode
        self.type = type
    }
    
    func toData() -> Data {
        var data = Data(bytes: &mode, count: MemoryLayout.size(ofValue: mode))
        data.append(Data(bytes: &type, count: MemoryLayout.size(ofValue: type)))
        return data
    }
}
