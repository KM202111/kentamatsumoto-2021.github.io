//
//  BT_Peripheral.swift
//  BT_NegiPeripheral
//
//  Created by hoehoe on 2018/06/10.
//  Copyright © 2018年 chocbanana. All rights reserved.
//

import CoreBluetooth


@objc protocol BT_PeripheralDelegate {
    func peripheral_Data( value:NSData )->Void

}

class BT_Peripheral: NSObject, CBPeripheralDelegate {
    var peripheral:CBPeripheral! = nil
    
    //12345678-1234-5678-1234-56789ABCDEF0
    private(set) var isNotify:Bool = false
    
    let notifyUUID:String! = "B8820003-95D7-4DD2-B5B3-07385E5E821F"
    let writeUUID:String! = "B8820002-95D7-4DD2-B5B3-07385E5E821F"
    
    let charUUIDs:Array<CBUUID>! = [ CBUUID(string: "B8820003-95D7-4DD2-B5B3-07385E5E821F"), CBUUID(string: "B8820002-95D7-4DD2-B5B3-07385E5E821F"), ]

    weak var delegate:BT_PeripheralDelegate?
    
    func setup()->Void{
        self.peripheral.delegate = self
    }
    
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        for service:CBService in peripheral.services! {
            
            print("service found")
            peripheral.discoverCharacteristics(charUUIDs, for: service)
            
        }
    }
    
    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        for characteristic:CBCharacteristic in service.characteristics! {
            //print(characteristic.uuid)
            
            if characteristic.uuid.uuidString == "B8820002-95D7-4DD2-B5B3-07385E5E821F" {
                print("write characteristic found")
                let writeMessage:BT_Message = BT_Message(mode: 0, type: 1)
                peripheral.writeValue(writeMessage.toData(), for: characteristic, type: .withResponse)
            }
            
            if characteristic.uuid.uuidString == "B8820003-95D7-4DD2-B5B3-07385E5E821F" {
                print("characteristic found")
                peripheral.setNotifyValue(true, for: characteristic)

            }

        }
    }
    
    func peripheral(_ peripheral: CBPeripheral, didUpdateNotificationStateFor characteristic: CBCharacteristic, error: Error?) {
        
        isNotify = characteristic.isNotifying
    }
    
    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
    
            let data:NSData = characteristic.value! as NSData
            delegate?.peripheral_Data(value: data)
    }

}
