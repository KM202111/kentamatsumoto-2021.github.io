//
//  Header.h
//  
//
//  Created by hoehoe on 2021/09/21.
//

#ifndef app_config_h
#define app_config_h

#define NRF_SOC_SD_PPI_CHANNELS_SD_ENABLED_MSK ((uint32_t)( \
      (1U << 17) \
    | (1U << 18) \
    | (1U << 19) \
    | (1U << 20) \
    | (1U << 21) \
    | (1U << 22) \
    | (1U << 23) \
    | (1U << 24) \
    | (1U << 25) \
    | (1U << 26) \
    | (1U << 27) \
    | (1U << 28) \
    | (1U << 29) \
    | (1U << 30) \
    | (1U << 31) \
  ))

#define NRF_SOC_SD_PPI_GROUPS_SD_ENABLED_MSK ((uint32_t)( \
(1U << 4) \
| (1U << 5) \
))


#endif /* Header_h */
