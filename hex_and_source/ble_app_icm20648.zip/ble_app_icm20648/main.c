/**
 * Copyright (c) 2014 - 2020, Nordic Semiconductor ASA
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form, except as embedded into a Nordic
 *    Semiconductor ASA integrated circuit in a product or a software update for
 *    such product, must reproduce the above copyright notice, this list of
 *    conditions and the following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 *
 * 3. Neither the name of Nordic Semiconductor ASA nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * 4. This software, with or without modification, must only be used with a
 *    Nordic Semiconductor ASA integrated circuit.
 *
 * 5. Any software provided in binary form under this license must not be reverse
 *    engineered, decompiled, modified and/or disassembled.
 *
 * THIS SOFTWARE IS PROVIDED BY NORDIC SEMICONDUCTOR ASA "AS IS" AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL NORDIC SEMICONDUCTOR ASA OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */
/** @file
 *
 * @defgroup ble_sdk_uart_over_ble_main main.c
 * @{
 * @ingroup  ble_sdk_app_icm20648_eval
 * @brief    UART over BLE application main file.
 *
 * This file contains the source code for a sample application that uses the Nordic UART service.
 * This application uses the @ref srvlib_conn_params module.
 */


#include <stdint.h>
#include <string.h>

//#include "app_timer.h"
//#include "app_uart.h"
#include "app_util_platform.h"
#include "bsp_btn_ble.h"
#include "nrf_pwr_mgmt.h"
#include "nrf_delay.h"

#include "nrf_drv_clock.h"
#include "nrf_gpio.h"
#include "nrf_drv_gpiote.h"

//#include "nrf_drv_ppi.h"
//#include "nrf_drv_timer.h"
#include "nrf.h"

#include "deviceIcm20648EVM.h"
#include "ble_my_srv.h"

#define DEAD_BEEF                       0xDEADBEEF                                  /**< Value used as error code on stack dump, can be used to identify stack location on stack unwind. */

//LED Timer Interval(ms)
//#define LED_TIMER_INTERVAL       (1000 * 3)
#define LED_SHOT_INTERVAL        50

//BLE Timer Interval(ms)
//#define BLE_TIMER_INTERVAL       (200)

// LED Timer instance.
//APP_TIMER_DEF(m_led_timer);
//APP_TIMER_DEF(m_ble_timer);

//static volatile bool isTick = false;

#define LED_ON 1
#define LED_OFF 0


 float accValueGlobal[3] = { 0.0f, };
 float gyrValueGlobal[3] = { 0.0f, };
 float quaValueGlobal[4] = { 0.0f, };

static uint8_t notifyValues[sizeof(float) * 10]  = { 0.0f, };


/**@brief Function for assert macro callback.
 *
 * @details This function will be called in case of an assert in the SoftDevice.
 *
 * @warning This handler is an example only and does not fit a final product. You need to analyse
 *          how your product is supposed to react in case of Assert.
 * @warning On assert from the SoftDevice, the system can only recover on reset.
 *
 * @param[in] line_num    Line number of the failing ASSERT call.
 * @param[in] p_file_name File name of the failing ASSERT call.
 */
void assert_nrf_callback(uint16_t line_num, const uint8_t * p_file_name)
{
    app_error_handler(DEAD_BEEF, line_num, p_file_name);
}

//LED
static void led_one_shot(uint32_t ms)
{
    nrf_gpio_pin_write(LED_1, LED_ON);
    nrf_delay_ms(ms);
    nrf_gpio_pin_write(LED_1, LED_OFF);
}

/**
 * @brief Function to be called in timer interrupt.
 *
 * @param[in] p_context     General purpose pointer (unused).
 */
//static void led_timer_handler(void *p_context)
//{
//    led_one_shot(LED_SHOT_INTERVAL);
//}

/**
 * @brief Function to be called in timer interrupt.
 *
 * @param[in] p_context     General purpose pointer (unused).
 */
//static void ble_timer_handler(void *p_context)
//{
//    isTick = true;
//}

//static void timer_start(void)
//{
//    uint32_t err_code;
//
//    err_code = app_timer_start(m_led_timer, APP_TIMER_TICKS(LED_TIMER_INTERVAL), NULL);
//    APP_ERROR_CHECK(err_code);
//
//    err_code = app_timer_start(m_ble_timer, APP_TIMER_TICKS(BLE_TIMER_INTERVAL), NULL);
//    APP_ERROR_CHECK(err_code);
//
//}

/**@brief Function for initializing the timer module.
 */
static void timers_init(void)
{
    ret_code_t err_code = app_timer_init();
    APP_ERROR_CHECK(err_code);

//    err_code = app_timer_create(&m_led_timer, APP_TIMER_MODE_REPEATED, led_timer_handler);
//    APP_ERROR_CHECK(err_code);
//
//    err_code = app_timer_create(&m_ble_timer, APP_TIMER_MODE_REPEATED, ble_timer_handler);
//    APP_ERROR_CHECK(err_code);
}


/**@brief Function for initializing power management.
 */
static void power_management_init(void)
{
    ret_code_t err_code;
    err_code = nrf_pwr_mgmt_init();
    APP_ERROR_CHECK(err_code);
}


/**@brief Function for handling the idle state (main loop).
 *
 * @details If there is no pending log operation, then sleep until next the next event occurs.
 */
static void idle_state_handle(void)
{
//    if (NRF_LOG_PROCESS() == false)
//    {
        nrf_pwr_mgmt_run();
//    }
}

/**@brief Function for putting the chip into sleep mode.
 *
 * @note This function will not return.
 */
//static void sleep_mode_enter(void)
//{
//    uint32_t err_code = bsp_indication_set(BSP_INDICATE_IDLE);
//    APP_ERROR_CHECK(err_code);
//
//    // Prepare wakeup buttons.
//    err_code = bsp_btn_ble_sleep_mode_prepare();
//    APP_ERROR_CHECK(err_code);
//
//    // Go to system-off mode (this function will not return; wakeup will cause a reset).
//    err_code = sd_power_system_off();
//    APP_ERROR_CHECK(err_code);
//}

/**@brief Function for handling events from the BSP module.
 *
 * @param[in]   event   Event generated by button press.
 */
void bsp_event_handler(bsp_event_t event)
{
    uint32_t err_code;
    switch (event)
    {
        case BSP_EVENT_SLEEP:
//            sleep_mode_enter();
            break;

        case BSP_EVENT_DISCONNECT:
              ble_gap_disconnect();
            break;

        case BSP_EVENT_WHITELIST_OFF:
            break;

        case BSP_EVENT_KEY_0:
            {
                 ble_icm20648_adv_start();
            }
            break;

        case BSP_EVENT_KEY_1:
            break;

        default:
            break;
    }
}

/**@brief Function for initializing buttons and leds.
 *
 * @param[out] p_erase_bonds  Will be true if the clear bonding button was pressed to wake the application up.
 */
static void buttons_leds_init(bool * p_erase_bonds)
{
    bsp_event_t startup_event;

    uint32_t err_code = bsp_init(BSP_INIT_LEDS | BSP_INIT_BUTTONS, bsp_event_handler);
    APP_ERROR_CHECK(err_code);

    err_code = bsp_btn_ble_init(NULL, &startup_event);
    APP_ERROR_CHECK(err_code);

    *p_erase_bonds = (startup_event == BSP_EVENT_CLEAR_BONDING_DATA);
}

/**
 * @brief Function that configures GPIOTE to give an interrupt on pin change.
 */
static void gpio_config(void)
{
    if(!nrf_drv_gpiote_is_init()) {
        uint32_t err_code;
        err_code = nrf_drv_gpiote_init();
        APP_ERROR_CHECK(err_code);
    }
    
    nrf_gpio_cfg_output(LED_1);
    nrf_gpio_pin_write(LED_1, LED_OFF);
}

/**
 * @brief Function for starting lfclk needed by APP_TIMER.
 */
static void lfclk_init(void)
{
    uint32_t err_code;
    err_code = nrf_drv_clock_init();
    APP_ERROR_CHECK(err_code);
    
    nrf_drv_clock_lfclk_request(NULL);
    
}

/**@brief Application main function.
 */
int main(void)
{

    bool erase_bonds;

    float tempValueGlobal = 0.0f;
    uint64_t sensorTimeStamp = 0;

    lfclk_init();
    timers_init();
    gpio_config();

    buttons_leds_init(&erase_bonds);
    power_management_init();

 

    memset(accValueGlobal, 0, sizeof(accValueGlobal));
    memset(gyrValueGlobal, 0, sizeof(gyrValueGlobal));
    memset(quaValueGlobal, 0, sizeof(quaValueGlobal));
    memset(notifyValues, 0, sizeof(notifyValues));

    led_one_shot(500);
    sensor_setup();
    setup_ble();
    sd_power_dcdc_mode_set(true);
    led_one_shot(500);

//    timer_start();

    // Enter main loop.
    while(true) {

        if( ble_icm20648_connected() == true && ble_icm20648_cccd_enabled() == true){
              sensor_poll();
          
              read_temperature(&tempValueGlobal);
              sensorTimeStamp = inv_icm20648_get_time_us();

              memcpy(notifyValues, accValueGlobal, sizeof(accValueGlobal));
              memcpy(&notifyValues[sizeof(float)*3], gyrValueGlobal, sizeof(gyrValueGlobal));
              memcpy(&notifyValues[sizeof(float)*6], quaValueGlobal, sizeof(quaValueGlobal));

              nrf_gpio_pin_write(LED_1, LED_ON);
              notify_value( (uint8_t *)notifyValues, sizeof(notifyValues) );
              nrf_gpio_pin_write(LED_1, LED_OFF);
        }

        idle_state_handle();

    }
}


/**
 * @}
 */
