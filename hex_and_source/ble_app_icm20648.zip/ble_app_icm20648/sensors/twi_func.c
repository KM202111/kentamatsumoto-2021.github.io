#include "twi_func.h"

#include "nrf_delay.h"
#include "boards.h"
#include "nrf_drv_twi.h"
#include "nrf_gpio.h"

#include "app_util_platform.h"
#include "app_error.h"


static uint8_t I2C_ADDR = 0x68;

/* TWI instance ID. */
#define TWI_INSTANCE_ID      0

/* Indicates if operation on TWI has ended. */
static volatile bool m_xfer_done = false;

/* TWI instance. */
static const nrf_drv_twi_t m_twi = NRF_DRV_TWI_INSTANCE(TWI_INSTANCE_ID);

/**
 * @brief TWI events handler.
 */
static void twi_handler(nrf_drv_twi_evt_t const * p_event, void * p_context)
{
	m_xfer_done = true;
//    switch (p_event->type)
//    {
//        case NRF_DRV_TWI_EVT_DONE:
//            m_xfer_done = true;
//            break;
//        default:
//            break;
//    }
}


void twi_init(uint8_t _I2C_ADDR)
{
    ret_code_t err_code;

    const nrf_drv_twi_config_t twi_config = {
        .scl                = 8, //ARDUINO_SCL_PIN,  //27
        .sda                = 7, //ARDUINO_SDA_PIN,  //26
        .frequency          = NRF_TWI_FREQ_100K,
        .interrupt_priority = APP_IRQ_PRIORITY_HIGH,
        .clear_bus_init = false
    };

    err_code = nrf_drv_twi_init(&m_twi, &twi_config, twi_handler, NULL);
    APP_ERROR_CHECK(err_code);

    nrf_drv_twi_enable(&m_twi);

    if(_I2C_ADDR != 0x68){
        I2C_ADDR = _I2C_ADDR;
    }
}


int twi_read_reg(uint8_t reg, uint8_t *data, uint32_t length)
{

  char data_[length];
  char data_write[1];
  data_write[0] = reg;

  m_xfer_done = false;
  APP_ERROR_CHECK( nrf_drv_twi_tx(&m_twi, I2C_ADDR, (uint8_t *)data_write, sizeof(data_write), true) ); //no stop
  while (m_xfer_done == false) { __WFE(); }

  nrf_delay_ms(1);

  m_xfer_done = false;
  APP_ERROR_CHECK( nrf_drv_twi_rx(&m_twi, I2C_ADDR, (uint8_t *)&data_, length) );
  while (m_xfer_done == false) { __WFE(); }

  nrf_delay_ms(2);

  for(int i = 0; i < length; i++) {
    data[i] = data_[i];
  }
	
	return NRF_SUCCESS;
}

int twi_write_reg(uint8_t reg, uint8_t *data, uint32_t length)
{

	uint8_t tx_data[(length+1)];

	tx_data[0] = reg;
	memcpy(&tx_data[1], data, length);
	
  m_xfer_done = false;
  APP_ERROR_CHECK( nrf_drv_twi_tx(&m_twi, I2C_ADDR, tx_data, sizeof(tx_data), true) ); //no stop
  while (m_xfer_done == false) { __WFE(); }

  nrf_delay_ms(1);

  return NRF_SUCCESS;
}
