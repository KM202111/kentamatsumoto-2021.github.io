/*
 * ________________________________________________________________________________________________________
 * Copyright (c) 2016-2016 InvenSense Inc. All rights reserved.
 *
 * This software, related documentation and any modifications thereto (collectively Software) is subject
 * to InvenSense and its licensors' intellectual property rights under U.S. and international copyright
 * and other intellectual property rights laws.
 *
 * InvenSense and its licensors retain all intellectual property and proprietary rights in and to the Software
 * and any use, reproduction, disclosure or distribution of the Software without an express license agreement
 * from InvenSense is strictly prohibited.
 *
 * EXCEPT AS OTHERWISE PROVIDED IN A LICENSE AGREEMENT BETWEEN THE PARTIES, THE SOFTWARE IS
 * PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT.
 * EXCEPT AS OTHERWISE PROVIDED IN A LICENSE AGREEMENT BETWEEN THE PARTIES, IN NO EVENT SHALL
 * INVENSENSE BE LIABLE FOR ANY DIRECT, SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, OR ANY
 * DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT,
 * NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE
 * OF THE SOFTWARE.
 * ________________________________________________________________________________________________________
 */

/**
 * @file
 * @brief This application allows sensor-cli to control the 20648, Nucleo being only an intermediate
 *        between the host running sensor-cli and the Invensense device. To be more precise, sensor-cli sends
 *        commands to the STM32F411 through an UART interface and the Dynamic protocol and the STM forwards
 *        these commands through an SPI interface to the 20648. This works the other
 *        way around too.
 *        There are two UART interface involved in the communication between Nucleo and the PC:
 *          - UART2 is used to output Nucleo's traces
 *          - UART1 is used by the PC to send and receive commands and sensor data from the 20648
 */

#include <stdint.h>
#include <stdio.h>

#include "nordic_common.h"

#include "deviceIcm20648EVM.h"

#include "Invn/Devices/DeviceIcm20648.h"
#include "Invn/Devices/HostSerif.h"

#include "nrf_delay.h"

#include "nrf_log.h"
#include "nrf_log_ctrl.h"
#include "nrf_log_default_backends.h"

#include "twi_func.h"


extern float accValueGlobal[3];
extern float gyrValueGlobal[3];
extern float quaValueGlobal[4];

/*
 * Set O/1 to start the following sensors in this example
 * NB: In case you are using IddWrapper (USE_IDDWRAPPER = 1), the following compile switch will have no effect.
 */
#define USE_RAW_ACC 0
#define USE_RAW_GYR 0
#define USE_GRV     1
#define USE_CAL_ACC 1
#define USE_CAL_GYR 1
//#define USE_CAL_MAG 0
#define USE_UCAL_GYR 0
//#define USE_UCAL_MAG 0
//#define USE_RV      0    /* requires COMPASS*/
//#define USE_GEORV   0    /* requires COMPASS*/
//#define USE_ORI     0    /* requires COMPASS*/
#define USE_STEPC   0
#define USE_STEPD   0
#define USE_SMD     0
#define USE_BAC     0
#define USE_TILT    0
#define USE_PICKUP  0
#define USE_GRAVITY 0
#define USE_LINACC  0
#define USE_B2S     0

/*
 * Sensor to start in this example
 */
//#if !USE_IDDWRAPPER
static const struct {
    uint8_t  type;
    uint32_t period_us;
} sensor_list[] = {
#if USE_RAW_ACC
    { INV_SENSOR_TYPE_RAW_ACCELEROMETER, 50000 /* 20 Hz */ },
#endif
#if USE_RAW_GYR
    { INV_SENSOR_TYPE_RAW_GYROSCOPE,     50000 /* 20 Hz */ },
#endif
#if USE_CAL_ACC
    { INV_SENSOR_TYPE_ACCELEROMETER, 50000 /* 20 Hz */ },
#endif
#if USE_CAL_GYR
    { INV_SENSOR_TYPE_GYROSCOPE, 50000 /* 20 Hz */ },
#endif
#if USE_CAL_MAG
    { INV_SENSOR_TYPE_MAGNETOMETER, 50000 /* 20 Hz */ },
#endif
#if USE_UCAL_GYR
    { INV_SENSOR_TYPE_UNCAL_GYROSCOPE, 50000 /* 20 Hz */ },
#endif
#if USE_UCAL_MAG
    { INV_SENSOR_TYPE_UNCAL_MAGNETOMETER, 50000 /* 20 Hz */ },
#endif
#if USE_GRV
    { INV_SENSOR_TYPE_GAME_ROTATION_VECTOR, 50000 /* 20 Hz */ },
#endif
#if USE_RV
    { INV_SENSOR_TYPE_ROTATION_VECTOR, 50000 /* 20 Hz */ },
#endif
#if USE_GEORV
    { INV_SENSOR_TYPE_GEOMAG_ROTATION_VECTOR, 50000 /* 20 Hz */ },
#endif
#if USE_ORI
    { INV_SENSOR_TYPE_ORIENTATION, 50000 /* 20 Hz */ },
#endif
#if USE_STEPC
    { INV_SENSOR_TYPE_STEP_COUNTER, ODR_NONE },
#endif
#if USE_STEPD
    { INV_SENSOR_TYPE_STEP_DETECTOR, ODR_NONE},
#endif
#if USE_SMD
    { INV_SENSOR_TYPE_SMD, ODR_NONE},
#endif
#if USE_BAC
    { INV_SENSOR_TYPE_BAC, ODR_NONE},
#endif
#if USE_TILT
    { INV_SENSOR_TYPE_TILT_DETECTOR, ODR_NONE},
#endif
#if USE_PICKUP
    { INV_SENSOR_TYPE_PICK_UP_GESTURE, ODR_NONE},
#endif
#if USE_GRA
    { INV_SENSOR_TYPE_GRAVITY, 50000 /* 20 Hz */},
#endif
#if USE_LINACC
    { INV_SENSOR_TYPE_LINEAR_ACCELERATION, 50000 /* 20 Hz */},
#endif
#if USE_B2S
    { INV_SENSOR_TYPE_B2S, ODR_NONE},
#endif
};


/* Host Serif object definition for SPI ***************************************/

static int idd_io_hal_init(void)
{
    twi_init(I2C_ADDR);
    return 0;
}

static int idd_io_hal_read_reg(uint8_t reg, uint8_t * rbuffer, uint32_t rlen)
{
    twi_read_reg(reg, rbuffer, rlen);
    return 0;
}

static int idd_io_hal_write_reg(uint8_t reg, const uint8_t * wbuffer, uint32_t wlen)
{
    twi_write_reg(reg, (uint8_t *)wbuffer, wlen);
    return 0;
}

static const inv_host_serif_t serif_instance = {
    idd_io_hal_init,
    0,
    idd_io_hal_read_reg,
    idd_io_hal_write_reg,
    0,
    1024*32, /* max transaction size */
    1024*32, /* max transaction size */
    INV_HOST_SERIF_TYPE_I2C,
};

static const inv_host_serif_t * idd_io_hal_get_serif_instance(void)
{
    return &serif_instance;
}


/* Forward declaration */
static void sensor_event_cb(const inv_sensor_event_t * event, void * arg);
void inv_icm20648_sleep_us(int us);
void inv_icm20648_sleep(int us);
uint64_t inv_icm20648_get_time_us(void);
static void check_rc(int rc);


/*
 * WHOAMI value for 20648
 */
static const uint8_t EXPECTED_WHOAMI[] = { 0xE0 };

/*
 * Icm20648 device require a DMP image to be loaded on init
 * Provide such images by mean of a byte array
 */
static const uint8_t dmp3_image[] = {
    #include "Invn/Images/icm20648_img.dmp3a.h"
};

/*
 * States for icm20648 device object
 */
static inv_device_icm20648_t device_icm20648;

/*
 * Just a handy variable to keep the handle to device object
 */
static inv_device_t * device;

/*
 * A listener object will handle sensor events
 */
static const inv_sensor_listener_t sensor_listener = {
    sensor_event_cb, /* callback that will receive sensor events */
    0                /* some pointer passed to the callback */
};

/* FSR configurations */
static int32_t cfg_acc_fsr = 2; // Default = +/- 4g. Valid ranges: 2, 4, 8, 16
static int32_t cfg_gyr_fsr = 250; // Default = +/- 2000dps. Valid ranges: 250, 500, 1000, 2000

/*
* Mounting matrix configuration applied for both Accel and Gyro
*/
static const float cfg_mounting_matrix[9]= {
    1.f, 0, 0,
    0, 1.f, 0,
    0, 0, 1.f
};

static void icm20648_apply_mounting_matrix(void){
    int ii;

    for (ii = 0; ii < sizeof(sensor_list)/sizeof(sensor_list[0]); ii++) {
        inv_icm20648_set_matrix(&device_icm20648.icm20648_states, cfg_mounting_matrix, ii);
    }
}

static void icm20648_set_fsr(void) {
//    inv_icm20648_set_fsr(&device_icm20648.icm20648_states, INV_ICM20648_SENSOR_RAW_ACCELEROMETER, (const void *)&cfg_acc_fsr);
    inv_icm20648_set_fsr(&device_icm20648.icm20648_states, INV_ICM20648_SENSOR_ACCELEROMETER, (const void *)&cfg_acc_fsr);
//    inv_icm20648_set_fsr(&device_icm20648.icm20648_states, INV_ICM20648_SENSOR_RAW_GYROSCOPE, (const void *)&cfg_gyr_fsr);
    inv_icm20648_set_fsr(&device_icm20648.icm20648_states, INV_ICM20648_SENSOR_GYROSCOPE, (const void *)&cfg_gyr_fsr);
//    inv_icm20648_set_fsr(&device_icm20648.icm20648_states, INV_ICM20648_SENSOR_GYROSCOPE_UNCALIBRATED, (const void *)&cfg_gyr_fsr);

}

int sensor_setup(void)
{
    int rc = 0;
    unsigned i = 0;

    uint8_t whoami = 0xff;

    /*
     * Welcome message
     */
    NRF_LOG_INFO("###################################");
    NRF_LOG_INFO("#          20648 example          #");
    NRF_LOG_INFO("###################################");
    NRF_LOG_FLUSH();

    /*
     * Open serial interface before using the device
     */
    NRF_LOG_INFO("Open I2C serial interface");
    NRF_LOG_FLUSH();
    rc += inv_host_serif_open(idd_io_hal_get_serif_instance());

    /*
     * Create icm20648 Device
     * Pass to the driver:
     * - reference to serial interface object,
     * - reference to listener that will catch sensor events,
     * - a static buffer for the driver to use as a temporary buffer
     * - various driver option
     */
    inv_device_icm20648_init(&device_icm20648, idd_io_hal_get_serif_instance(),
            &sensor_listener, dmp3_image, sizeof(dmp3_image));

    /*
     * Simply get generic device handle from icm20648 Device
     */
    device = inv_device_icm20648_get_base(&device_icm20648);

    /*
     * Just get the whoami
     */
    for(int j=0; i<5; j++){
        rc = inv_device_whoami(device, &whoami);
        NRF_LOG_INFO("ICM WHOAMI=%02x", whoami);
        NRF_LOG_FLUSH();
        check_rc(rc);

        if( whoami == EXPECTED_WHOAMI[0] ) {
            break;
        }

    }
    /*
     * Check if WHOAMI value corresponds to any value from EXPECTED_WHOAMI array
     */
//         if( whoami != EXPECTED_WHOAMI[0] ) {
//             NRF_LOG_INFO("Bad WHOAMI value. Got 0x%02x. Expected @EXPECTED_WHOAMI@.", whoami);
//             NRF_LOG_FLUSH();
//             return -1;
//         }

//    for(i = 0; i < sizeof(EXPECTED_WHOAMI)/sizeof(EXPECTED_WHOAMI[0]); ++i) {
//            if(whoami == EXPECTED_WHOAMI[i]){
//                break;
//            }
//    }
//
//    if(i == sizeof(EXPECTED_WHOAMI)/sizeof(EXPECTED_WHOAMI[0])) {
//            NRF_LOG_INFO("Bad WHOAMI value. Got 0x%02x. Expected @EXPECTED_WHOAMI@.", whoami);
//        check_rc(-1);
//    }

    /*
     * Configure and initialize the icm20648 device
     */
    NRF_LOG_INFO("Setting-up ICM device");
    NRF_LOG_FLUSH();
    rc = inv_device_setup(device);
    check_rc(rc);

    /* Setup accel and gyro mounting matrix and associated angle for current board */
    inv_icm20648_init_matrix(&device_icm20648.icm20648_states);
    /*
     * Now that Icm20648 device was inialized, we can proceed with DMP image loading
     * This step is mandatory as DMP image are not store in non volatile memory
     */
    NRF_LOG_INFO("Load DMP3 image");
    NRF_LOG_FLUSH();
    rc = inv_device_load(device, NULL, dmp3_image, sizeof(dmp3_image), true /* verify */, NULL);
    check_rc(rc);
    

    icm20648_apply_mounting_matrix();
    icm20648_set_fsr();
    /*
     * Start all available sensors from the sensor list
     */
    for(i = 0; i < sizeof(sensor_list)/sizeof(sensor_list[0]); ++i) {
        rc  = inv_device_set_sensor_period_us(device, sensor_list[i].type, sensor_list[i].period_us);
        check_rc(rc);
        rc += inv_device_start_sensor(device, sensor_list[i].type);
        check_rc(rc);
    }

    return 0;
}

void sensor_poll(void)
{

     int rc = 0;
     rc = inv_device_poll(device);

}


/*
 * Callback called upon sensor event reception
 * This function is called in the same context as inv_device_poll()
 */
static void sensor_event_cb(const inv_sensor_event_t * event, void * arg)
{
    /* arg will contained the value provided at init time */
    (void)arg;


         /*
     * In normal mode, display sensor event over UART messages
     */

    if(event->status == INV_SENSOR_STATUS_DATA_UPDATED) {

    switch(INV_SENSOR_ID_TO_TYPE(event->sensor)) {
            case INV_SENSOR_TYPE_RAW_ACCELEROMETER:
            case INV_SENSOR_TYPE_RAW_GYROSCOPE:
            {
                NRF_LOG_INFO("data event %s (lsb): %llu %d %d %d", inv_sensor_str(event->sensor),
                                event->timestamp,
                                (int)event->data.raw3d.vect[0],
                                (int)event->data.raw3d.vect[1],
                                (int)event->data.raw3d.vect[2]);
                NRF_LOG_FLUSH();
            }
                break;
      
            case INV_SENSOR_TYPE_ACCELEROMETER:
            case INV_SENSOR_TYPE_LINEAR_ACCELERATION:
            case INV_SENSOR_TYPE_GRAVITY:
            {
                memcpy(accValueGlobal, event->data.acc.vect, sizeof(accValueGlobal));

            }
                break;
      
            case INV_SENSOR_TYPE_GYROSCOPE:
            {
                memcpy(gyrValueGlobal, event->data.gyr.vect, sizeof(gyrValueGlobal));
            }
                    break;
      
            case INV_SENSOR_TYPE_MAGNETOMETER:
    //            INV_MSG(INV_MSG_LEVEL_INFO, "data event %s (nT): %d %d %d", inv_sensor_str(event->sensor),
    //                    (int)(event->data.mag.vect[0]*1000),
    //                    (int)(event->data.mag.vect[1]*1000),
    //                    (int)(event->data.mag.vect[2]*1000));
                    break;
            case INV_SENSOR_TYPE_UNCAL_GYROSCOPE:
    //            INV_MSG(INV_MSG_LEVEL_INFO, "data event %s (mdps): %d %d %d %d %d %d", inv_sensor_str(event->sensor),
    //                    (int)(event->data.gyr.vect[0]*1000),
    //                    (int)(event->data.gyr.vect[1]*1000),
    //                    (int)(event->data.gyr.vect[2]*1000),
    //                    (int)(event->data.gyr.bias[0]*1000),
    //                    (int)(event->data.gyr.bias[1]*1000),
    //                    (int)(event->data.gyr.bias[2]*1000));
                    break;
            case INV_SENSOR_TYPE_UNCAL_MAGNETOMETER:
    //            INV_MSG(INV_MSG_LEVEL_INFO, "data event %s (nT): %d %d %d %d %d %d", inv_sensor_str(event->sensor),
    //                    (int)(event->data.mag.vect[0]*1000),
    //                    (int)(event->data.mag.vect[1]*1000),
    //                    (int)(event->data.mag.vect[2]*1000),
    //                    (int)(event->data.mag.bias[0]*1000),
    //                    (int)(event->data.mag.bias[1]*1000),
    //                    (int)(event->data.mag.bias[2]*1000));
                    break;
            case INV_SENSOR_TYPE_GAME_ROTATION_VECTOR:
            case INV_SENSOR_TYPE_ROTATION_VECTOR:
            case INV_SENSOR_TYPE_GEOMAG_ROTATION_VECTOR:
            {
                memcpy(quaValueGlobal, event->data.quaternion.quat, sizeof(quaValueGlobal));

            }
                    break;
            case INV_SENSOR_TYPE_ORIENTATION:
    //                NRF_LOG_INFO("data event %s (e-3): %d %d %d %d ", inv_sensor_str(event->sensor),
    //                    (int)(event->data.orientation.x*1000),
    //                    (int)(event->data.orientation.y*1000),
    //                    (int)(event->data.orientation.z*1000));
    //                NRF_LOG_FLUSH();
                    break;
            case INV_SENSOR_TYPE_BAC:
    //                NRF_LOG_INFO("data event %s : %d %s", inv_sensor_str(event->sensor),
    //                    event->data.bac.event, activityName(event->data.bac.event));
            NRF_LOG_FLUSH();
                    break;
            case INV_SENSOR_TYPE_STEP_COUNTER:
    //                NRF_LOG_INFO("data event %s : %lu", inv_sensor_str(event->sensor),
    //                    (unsigned long)event->data.step.count);
    //                NRF_LOG_FLUSH();
                    break;
            case INV_SENSOR_TYPE_PICK_UP_GESTURE:
            case INV_SENSOR_TYPE_STEP_DETECTOR:
            case INV_SENSOR_TYPE_SMD:
            case INV_SENSOR_TYPE_B2S:
            case INV_SENSOR_TYPE_TILT_DETECTOR:
            default:
                {
                    NRF_LOG_INFO("data event %s : ...", inv_sensor_str(event->sensor));
                    NRF_LOG_FLUSH();
                }
                break;
        }
    }
}


void inv_icm20648_sleep_us(int us)
{
    nrf_delay_us(us);
}

static volatile uint32_t overflows = 0;
static uint32_t micros( void )
{
    uint64_t ticks = (uint64_t)((uint64_t)overflows << (uint64_t)24) | (uint64_t)(NRF_RTC1->COUNTER);
    
    return (ticks * 1000000) / 32768;
}


uint64_t inv_icm20648_get_time_us(void) {
    return micros();
//    return 0;
}


static void check_rc(int rc)
{
    if(rc == -1) {
        NRF_LOG_INFO("BAD RC=%d", rc);
        while(1);
    }
}

uint32_t read_temperature(float *temperature)
{
    uint8_t data[2];
    int16_t raw_temp;

    /* Read temperature registers */
    //read_register(ICM20648_REG_TEMPERATURE_H, 2, data);
    idd_io_hal_read_reg(REG_TEMPERATURE, data, 2);

    /* Convert to int16 */
    raw_temp = (int16_t) ( (data[0] << 8) + data[1]);

    /* Calculate the Celsius value from the raw reading */
    *temperature = ( (float) raw_temp / 333.87) + 21.0;

    return 0;
}





//void apply_stored_offsets(void)
//{
//    uint8_t sensor_bias[84];
//    int32_t acc_bias_q16[6] = {0}, gyro_bias_q16[6] = {0};
//    uint8_t i, idx = 0;
//    int rc;
//
//    /* Retrieve Sel-test offsets stored in NV memory */
//    if(flash_manager_readData(sensor_bias) != 0) {
//        INV_MSG(INV_MSG_LEVEL_WARNING, "No bias values retrieved from NV memory !");
//        return;
//    }
//
//    for(i = 0; i < 6; i++)
//        gyro_bias_q16[i] = inv_dc_little8_to_int32((const uint8_t *)(&sensor_bias[i * sizeof(uint32_t)]));
//    idx += sizeof(gyro_bias_q16);
//    rc = inv_device_set_sensor_config(device, INV_SENSOR_TYPE_GYROSCOPE,
//        VSENSOR_CONFIG_TYPE_OFFSET, gyro_bias_q16, sizeof(gyro_bias_q16));
//    check_rc(rc);
//
//    for(i = 0; i < 6; i++)
//        acc_bias_q16[i] = inv_dc_little8_to_int32((const uint8_t *)(&sensor_bias[idx + i * sizeof(uint32_t)]));
//    idx += sizeof(acc_bias_q16);
//    rc = inv_device_set_sensor_config(device, INV_SENSOR_TYPE_ACCELEROMETER,
//        VSENSOR_CONFIG_TYPE_OFFSET, acc_bias_q16, sizeof(acc_bias_q16));
//
//}
//
//void store_offsets(void)
//{
//    int rc = 0;
//    uint8_t i, idx = 0;
//    int gyro_bias_q16[6] = {0}, acc_bias_q16[6] = {0};
//
//    uint8_t sensor_bias[84] = {0};
//
//    /* Strore Self-test bias in NV memory */
//    rc = inv_device_get_sensor_config(device, INV_SENSOR_TYPE_GYROSCOPE,
//            VSENSOR_CONFIG_TYPE_OFFSET, gyro_bias_q16, sizeof(gyro_bias_q16));
//    check_rc(rc);
//    for(i = 0; i < 6; i++)
//        inv_dc_int32_to_little8(gyro_bias_q16[i], &sensor_bias[i * sizeof(uint32_t)]);
//    idx += sizeof(gyro_bias_q16);
//
//    rc = inv_device_get_sensor_config(device, INV_SENSOR_TYPE_ACCELEROMETER,
//            VSENSOR_CONFIG_TYPE_OFFSET, acc_bias_q16, sizeof(acc_bias_q16));
//    check_rc(rc);
//    for(i = 0; i < 6; i++)
//        inv_dc_int32_to_little8(acc_bias_q16[i], &sensor_bias[idx + i * sizeof(uint32_t)]);
//    idx += sizeof(acc_bias_q16);
//
//    flash_manager_writeData(sensor_bias);
//}

