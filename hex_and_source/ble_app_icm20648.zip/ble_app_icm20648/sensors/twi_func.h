#include <stdint.h>
//#include <stdio.h>
#include <assert.h>
#include <string.h>

void twi_init(uint8_t _I2C_ADDR);
int twi_read_reg(uint8_t reg, uint8_t *data, uint32_t length);
int twi_write_reg(uint8_t reg, uint8_t *data, uint32_t length);
