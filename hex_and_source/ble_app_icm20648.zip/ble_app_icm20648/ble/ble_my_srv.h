#include <stdint.h>
//#include <stdio.h>
#include <assert.h>
#include <string.h>

int setup_ble(void);
int notify_value( uint8_t *ctx, uint16_t ctx_len );

void ble_icm20648_adv_start(void);
bool ble_icm20648_connected(void);
bool ble_icm20648_cccd_enabled(void);
void ble_gap_disconnect(void);