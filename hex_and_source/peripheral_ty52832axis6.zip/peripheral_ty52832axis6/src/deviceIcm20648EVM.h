/*
 * Copyright (c) 2016 Intel Corporation
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#ifndef ZEPHYR_DRIVERS_SENSOR_ICM20648_ICM20648_H_
#define ZEPHYR_DRIVERS_SENSOR_ICM20648_ICM20648_H_

#include <zephyr.h>

#define AXIS6      0
#define VEC        1
#define STEP_COUNT 2
#define LINER      3

#define MODE       0
#define RANGE      1


void icm20648_setup(void);
void icm20648_sample_fetch(void);
//void icm20648_sleep_enable(bool enable);
uint32_t read_temperature(float *temperature);
void icm20648_write_command(uint8_t type, uint8_t* command, uint8_t command_len);
uint8_t icm20648_current_type(void);
uint8_t icm20648_current_acc_fsr(void);
uint8_t icm20648_current_gyr_fsr(void);

#endif /* ZEPHYR_DRIVERS_SENSOR_ICM20648_ICM20648_H_ */
