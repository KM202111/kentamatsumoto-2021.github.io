/*
 * ________________________________________________________________________________________________________
 * Copyright (c) 2016-2016 InvenSense Inc. All rights reserved.
 *
 * This software, related documentation and any modifications thereto (collectively Software) is subject
 * to InvenSense and its licensors' intellectual property rights under U.S. and international copyright
 * and other intellectual property rights laws.
 *
 * InvenSense and its licensors retain all intellectual property and proprietary rights in and to the Software
 * and any use, reproduction, disclosure or distribution of the Software without an express license agreement
 * from InvenSense is strictly prohibited.
 *
 * EXCEPT AS OTHERWISE PROVIDED IN A LICENSE AGREEMENT BETWEEN THE PARTIES, THE SOFTWARE IS
 * PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT.
 * EXCEPT AS OTHERWISE PROVIDED IN A LICENSE AGREEMENT BETWEEN THE PARTIES, IN NO EVENT SHALL
 * INVENSENSE BE LIABLE FOR ANY DIRECT, SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, OR ANY
 * DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT,
 * NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE
 * OF THE SOFTWARE.
 * ________________________________________________________________________________________________________
 */

/**
 * @file
 * @brief This application allows sensor-cli to control the 20649, Nucleo being only an intermediate 
 *        between the host running sensor-cli and the Invensense device. To be more precise, sensor-cli sends
 *        commands to the STM32F411 through an UART interface and the Dynamic protocol and the STM forwards
 *        these commands through an SPI interface to the 20649. This works the other 
 *        way around too. 
 *        There are two UART interface involved in the communication between Nucleo and the PC:
 *          - UART2 is used to output Nucleo's traces
 *          - UART1 is used by the PC to send and receive commands and sensor data from the 20649
 */

#include <stdint.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>

#include <logging/log.h>

#include <stdint.h>
#include <stdio.h>

#include <device.h>
#include <zephyr/types.h>
#include <sys/util.h>
#include <sys/slist.h>
#include <drivers/i2c.h>
#include <zephyr.h>

#include "Invn/Message.h"
#include "Invn/DataConverter.h"
#include "Invn/DeviceIcm20649.h"

#include "deviceIcm20649EVM.h"

/*
 * Set O/1 to start the following sensors in this example
 * NB: In case you are using IddWrapper (USE_IDDWRAPPER = 1), the following compile switch will have no effect.
 */
#define USE_RAW_ACC 0
#define USE_RAW_GYR 0
#define USE_GRV     1
#define USE_WOM     0
#define USE_SCALED_ACC 1
#define USE_CAL_GYR 1
#define USE_UCAL_GYR 0

/*
 * Sensor to start in this example
 */

static const struct {
	uint8_t  type;
	uint32_t period_us;
} sensor_list[] = {
#if USE_RAW_ACC
	{ INV_SENSOR_TYPE_RAW_ACCELEROMETER, 50000 /* 20 Hz */ },
#endif
#if USE_RAW_GYR
	{ INV_SENSOR_TYPE_RAW_GYROSCOPE,     50000 /* 20 Hz */ },
#endif
#if USE_WOM
	{ INV_SENSOR_TYPE_WOM, 0 /* does not apply */ },
#endif
#if USE_SCALED_ACC
	{ INV_SENSOR_TYPE_ACCELEROMETER, 50000 /* 20 Hz */ },
#endif
#if USE_CAL_GYR
	{ INV_SENSOR_TYPE_GYROSCOPE, 50000 /* 20 Hz */ },
#endif
#if USE_UCAL_GYR
	{ INV_SENSOR_TYPE_UNCAL_GYROSCOPE, 50000 /* 20 Hz */ },
#endif
#if USE_GRV
	{ INV_SENSOR_TYPE_GAME_ROTATION_VECTOR, 50000 /* 20 Hz */ },
#endif
};

extern float accValueGlobal[3];
extern float gyrValueGlobal[3];
extern float quaValueGlobal[4];
extern float temperature;

/* FSR configurations */
static int32_t cfg_acc_fsr = 16; // Default = +/- 4g. Valid ranges: 2, 4, 8, 16
static int32_t cfg_gyr_fsr = 250; // Default = +/- 2000dps. Valid ranges: 250, 500, 1000, 2000

/*
 * WHOAMI value for 20649
 */
static const uint8_t EXPECTED_WHOAMI[] = { 0xE1 };

/*
 * Icm20649 device require a DMP image to be loaded on init
 * Provide such images by mean of a byte array
 */
static const uint8_t dmp3_image[] = {
    #include "icm20649_img.dmp3a.h"
//    0
};


static struct device *i2c_dev;

static void twi_init(void)
{
    uint32_t i2c_cfg = I2C_SPEED_SET(I2C_SPEED_STANDARD) | I2C_MODE_MASTER;
    //I2C_SPEED_SET(I2C_SPEED_STANDARD) | I2C_MODE_MASTER;
    const char dev_name[] = "I2C_0";
    i2c_dev = device_get_binding(dev_name);

    if (i2c_dev == NULL) {
//        printk("Failed to get pointer to i2c device\n");
        return ;
    }else{
        i2c_configure(i2c_dev, i2c_cfg);
    }
    
//    printk("i2c init done.\n");

}


static int twi_read_reg(uint8_t reg, uint8_t *data, uint32_t length)
{

// --- Default ---
    i2c_burst_read(i2c_dev, 0x68, reg, data, length);
//--- ---

    return 0;
}

static int twi_write_reg(uint8_t reg, uint8_t *data, uint32_t length)
{

// --- Default ---
    uint8_t tx_data[(length+1)];

    tx_data[0] = reg;
    memcpy(&tx_data[1], data, length);
    i2c_write(i2c_dev, tx_data, sizeof(tx_data), 0x68);
//--- ---
       
    return 0;
}


/* Host Serif object definition for SPI ***************************************/

static int idd_io_hal_init(void)
{
    twi_init();
    return 0;
}

static int idd_io_hal_read_reg(uint8_t reg, uint8_t * rbuffer, uint32_t rlen)
{
    twi_read_reg(reg, rbuffer, rlen);
    return 0;
}

static int idd_io_hal_write_reg(uint8_t reg, const uint8_t * wbuffer, uint32_t wlen)
{
    twi_write_reg(reg, (uint8_t *)wbuffer, wlen);
    return 0;
}

static const inv_host_serif_t serif_instance = {
    idd_io_hal_init,
    0,
    idd_io_hal_read_reg,
    idd_io_hal_write_reg,
    0,
    1024*32, /* max transaction size */
    1024*32, /* max transaction size */
    INV_HOST_SERIF_TYPE_I2C,
};

static const inv_host_serif_t * idd_io_hal_get_serif_instance(void)
{
    return &serif_instance;
}




//uint64_t inv_icm20649_get_dataready_interrupt_time_us(void);

/* Forward declaration */
//void ext_interrupt_cb(void * context, int int_num);
static void sensor_event_cb(const inv_sensor_event_t * event, void * arg);
static int icm20649_sensor_configuration(void);
void inv_icm20649_sleep_us(int us);
uint64_t inv_icm20649_get_time_us(void);
//uint64_t inv_icm20649_get_dataready_interrupt_time_us(void);
//static void check_rc(int rc);



/*
 * States for icm20649 device object
 */
static inv_device_icm20649_t device_icm20649;

/* 
 * Just a handy variable to keep the handle to device object
 */
static inv_device_t * device; 

/*
 * A listener object will handle sensor events
 */
static const inv_sensor_listener_t sensor_listener = {
	sensor_event_cb, /* callback that will receive sensor events */
	0                /* some pointer passed to the callback */
};


/* WOM treshold configuration */
static inv_device_icm20649_config_wom_threshold_t cfg_wom_threshold = 0x30;

/*
* Mounting matrix configuration applied for both Accel and Gyro
*/
static const float cfg_mounting_matrix[9]= {
    1.f, 0, 0,
    0, 1.f, 0,
    0, 0, 1.f
};

static void icm20649_apply_mounting_matrix(void)
{
    for (int i = 0; i < sizeof(sensor_list)/sizeof(sensor_list[0]); i++) {
        inv_icm20649_set_matrix(&device_icm20649.icm20649_states, cfg_mounting_matrix, i);
    }
}

static void icm20649_set_fsr(void) {

    inv_icm20649_set_fsr(&device_icm20649.icm20649_states,
                         INV_ICM20649_SENSOR_ACCELEROMETER, (const void *)&cfg_acc_fsr);
    
    inv_icm20649_set_fsr(&device_icm20649.icm20649_states,
                         INV_ICM20649_SENSOR_GYROSCOPE, (const void *)&cfg_gyr_fsr);
}


int icm20649_setup(void)
{


	/*
	 * Welcome message
	 */
    //printk("###################################\r\n");
    //printk("#          20649 example          #\r\n");
    //printk("###################################\r\n");


//	/*
//	 * Open serial interface before using the device
//	 * Init SPI communication: SPI1 - SCK(PA5) / MISO(PA6) / MOSI(PA7) / CS(PB6)
//	 */

        int rc = 0;
        rc = inv_host_serif_open(idd_io_hal_get_serif_instance());

	/*
	 * Create icm20649 Device 
	 * Pass to the driver:
	 * - reference to serial interface object,
	 * - reference to listener that will catch sensor events,
	 * - a static buffer for the driver to use as a temporary buffer
	 * - various driver option
	 */
	inv_device_icm20649_init(&device_icm20649, idd_io_hal_get_serif_instance(),
			&sensor_listener, dmp3_image, sizeof(dmp3_image));

	/*
	 * Simply get generic device handle from icm20649 Device
	 */
	device = inv_device_icm20649_get_base(&device_icm20649);

	/*
	 * Just get the whoami
	 */
        uint8_t whoami = 0xff;
    
        for(int i=0; i<5; i++) {

            inv_device_whoami(device, &whoami);

            if( whoami == EXPECTED_WHOAMI[0] ) {
                break;
            }

        }
	

	/*
	 * Configure and initialize the icm20649 device
	 */
	//INV_MSG(INV_MSG_LEVEL_INFO, "Setting-up ICM device");
	rc = inv_device_setup(device);
//	check_rc(rc);
	
    inv_icm20649_init_matrix(&device_icm20649.icm20649_states);

	/*
	 * Now that Icm20649 device was inialized, we can proceed with DMP image loading
	 * This step is mandatory as DMP image are not store in non volatile memory
	 */
	//INV_MSG(INV_MSG_LEVEL_INFO, "Load DMP3 image");
	rc = inv_device_load(device, NULL, dmp3_image, sizeof(dmp3_image), true /* verify */, NULL);
//	check_rc(rc);
	
    icm20649_apply_mounting_matrix();
    icm20649_set_fsr();
	icm20649_sensor_configuration();

        for(int i = 0; i < sizeof(sensor_list)/sizeof(sensor_list[0]); ++i) {
             rc  = inv_device_set_sensor_period_us(device,
                           sensor_list[i].type, sensor_list[i].period_us);
        }

        for(int i = 0; i < sizeof(sensor_list)/sizeof(sensor_list[0]); ++i) {
             rc = inv_device_start_sensor(device, sensor_list[i].type);
        }

        return 0;
}



/*
 * Callback called upon sensor event reception
 * This function is called in the same context as inv_device_poll()
 */
 void sensor_event_cb(const inv_sensor_event_t * event, void * arg)
{
	/* arg will contained the value provided at init time */
	(void)arg;

	if(event->status == INV_SENSOR_STATUS_DATA_UPDATED) {

		switch(INV_SENSOR_ID_TO_TYPE(event->sensor)) {
		case INV_SENSOR_TYPE_RAW_ACCELEROMETER:
		case INV_SENSOR_TYPE_RAW_GYROSCOPE:
			//printf("data event %s (lsb): %d %d %d\r\n", inv_sensor_str(event->sensor),
			//		//event->timestamp,
			//		(int)event->data.raw3d.vect[0],
			//		(int)event->data.raw3d.vect[1],
			//		(int)event->data.raw3d.vect[2]);
			break;
		case INV_SENSOR_TYPE_ACCELEROMETER:
                {
                      memcpy(accValueGlobal, event->data.acc.vect, sizeof(accValueGlobal));
                }
//			printf("data event %s (mg): %d %d %d\r\n", inv_sensor_str(event->sensor),
//					(int)(event->data.acc.vect[0]*1000),
//					(int)(event->data.acc.vect[1]*1000),
//					(int)(event->data.acc.vect[2]*1000));
                
			break;
		case INV_SENSOR_TYPE_GYROSCOPE:
//			printf("data event %s (mdps): %d %d %d\r\n", inv_sensor_str(event->sensor),
//					(int)(event->data.gyr.vect[0]*1000),
//					(int)(event->data.gyr.vect[1]*1000),
//					(int)(event->data.gyr.vect[2]*1000));
                {
                        memcpy(gyrValueGlobal, event->data.gyr.vect, sizeof(gyrValueGlobal));
                }
			break;
		case INV_SENSOR_TYPE_UNCAL_GYROSCOPE:
			//printf( "data event %s (mdps): %d %d %d %d %d %d\r\n", inv_sensor_str(event->sensor),
			//		(int)(event->data.gyr.vect[0]*1000),
			//		(int)(event->data.gyr.vect[1]*1000),
			//		(int)(event->data.gyr.vect[2]*1000),
			//		(int)(event->data.gyr.bias[0]*1000),
			//		(int)(event->data.gyr.bias[1]*1000),
			//		(int)(event->data.gyr.bias[2]*1000));
			break;
		case INV_SENSOR_TYPE_GAME_ROTATION_VECTOR:
//			printf("data event %s (e-3): %d %d %d %d \r\n", inv_sensor_str(event->sensor),
//					(int)(event->data.quaternion.quat[0]*1000),
//					(int)(event->data.quaternion.quat[1]*1000),
//					(int)(event->data.quaternion.quat[2]*1000),
//					(int)(event->data.quaternion.quat[3]*1000));
                {
                      memcpy(quaValueGlobal, event->data.quaternion.quat, sizeof(quaValueGlobal));
                }
			break;
		case INV_SENSOR_TYPE_WOM:
                    break;
		default:
			printf("data event %s : ...\r\n", inv_sensor_str(event->sensor));
			break;
		}
	}
}

 int icm20649_sensor_configuration(void)
{
	int rc;
	/* Set WOM Threshold*/
	rc  = inv_device_set_sensor_config(device, INV_SENSOR_TYPE_WOM,
			INV_DEVICE_ICM20649_CONFIG_WOM_THRESHOLD, &cfg_wom_threshold, sizeof(cfg_wom_threshold));
	return rc;
}

void inv_icm20649_sleep_us(int us) {
    k_sleep(K_USEC(us));


}

static volatile uint32_t overflows = 0;
uint64_t inv_icm20649_get_time_us(void) {
    
    uint64_t ticks = (uint64_t)((uint64_t)overflows << (uint64_t)24) | (uint64_t)k_uptime_get();
    return (ticks * 1000000) / 32768;
    
}


//void check_rc(int rc) {
//	if(rc == -1) {
////		printf("BAD RC=%d\r\n", rc);
//		while(1);
       
//	}

//}

void icm20649_sample_fetch(void){
    int rc = 0;
    rc = inv_device_poll(device);
}

uint32_t read_temperature(float *temperature)
{
    uint8_t data[2];
    int16_t raw_temp;
 
    /* Read temperature registers */
    #define ICM20649_BANK_0                  (0 << 7)     /**< Register bank 0 */
    #define ICM20649_REG_TEMPERATURE_H         (ICM20649_BANK_0 | 0x39)
    twi_read_reg(ICM20649_REG_TEMPERATURE_H, data, 2);
    
    //read_register(ICM20648_REG_TEMPERATURE_H, 2, data);
 
    /* Convert to int16 */
    raw_temp = (int16_t) ( (data[0] << 8) + data[1]);
 
    /* Calculate the Celsius value from the raw reading */
    *temperature = ( (float) raw_temp / 333.87) + 21.0;
 
    return 0;
}

void icm20649_write_command(uint8_t* command, uint8_t command_len){

    //Accel FSR
    switch(command[0]){
        case 0:
          cfg_acc_fsr = 2;
          break;
        case 1:
          cfg_acc_fsr = 4;
          break;
        case 2:
          cfg_acc_fsr = 8;
          break;
        case 3:
          cfg_acc_fsr = 16;
          break;
        default:
          cfg_acc_fsr = 2;
          break;
    }

    //Gyro FSR
    switch(command[1]){
        case 0:
          cfg_gyr_fsr = 250;
          break;
        case 1:
          cfg_gyr_fsr = 500;
          break;
        case 2:
          cfg_gyr_fsr = 1000;
          break;
        case 3:
          cfg_gyr_fsr = 2000;
          break;
        default:
          cfg_gyr_fsr = 250;
          break;
    }
  
//        printf("Accel FSR: %d\n", cfg_acc_fsr);
//        printf("Gyro  FSR: %d\n", cfg_gyr_fsr);

    icm20649_set_fsr();
}

uint8_t icm20649_current_acc_fsr(void){
    return cfg_acc_fsr;
}
uint8_t icm20649_current_gyr_fsr(void){
    return cfg_gyr_fsr;
}
