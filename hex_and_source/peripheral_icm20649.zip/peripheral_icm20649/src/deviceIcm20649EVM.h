//
//  Header.h
//  
//
//  Created by hoehoe on 2021/10/18.
//

#ifndef Header_h
#define Header_h

int icm20649_setup(void);
void icm20649_sample_fetch(void);
//void icm20648_sleep_enable(bool enable);
uint32_t read_temperature(float *temperature);
void icm20649_write_command(uint8_t* command, uint8_t command_len);
//uint8_t icm20649_current_type(void);
uint8_t icm20649_current_acc_fsr(void);
uint8_t icm20649_current_gyr_fsr(void);

#endif /* Header_h */
