/*
 * Copyright (c) 2022 Deden LLC.
 *
 * SPDX-License-Identifier: LicenseRef-BSD-5-Clause-Nordic
 */

#include <zephyr/types.h>
#include <zephyr.h>

#include <device.h>
#include <soc.h>

#include <bluetooth/bluetooth.h>
#include <bluetooth/uuid.h>
#include <bluetooth/gatt.h>
#include <bluetooth/hci.h>

#include <dk_buttons_and_leds.h>
#include <settings/settings.h>

#include <stdio.h>

#include "deviceIcm20649EVM.h"
#include "ble_services/axs.h"


/* SENSOR Value */
float accValueGlobal[3] = {0.0f};
float gyrValueGlobal[3] = {0.0f};
float quaValueGlobal[4] = {0.0f};
float temperature = 0.0f;
float timeStamp = 0.0f;

//static uint8_t sensor_type = 0;

/* LED DEFINE */
#define RUN_STATUS_LED DK_LED1

#define LED_ON 0
#define LED_OFF 1

/* Structures for work */
//static struct k_delayed_work leds_update_work;


/* BUTTON */
//struct k_timer button_timer; //Button Long push timer.


/* BT */
#define DEVICE_NAME CONFIG_BT_DEVICE_NAME
#define DEVICE_NAME_LEN    (sizeof(DEVICE_NAME) - 1)

static struct bt_conn *current_conn;
static uint16_t mtu;

static const struct bt_data ad[] = {
    BT_DATA_BYTES(BT_DATA_FLAGS, (BT_LE_AD_GENERAL | BT_LE_AD_NO_BREDR)),
    BT_DATA(BT_DATA_NAME_COMPLETE, DEVICE_NAME, DEVICE_NAME_LEN),
};

static const struct bt_data sd[] = {
    BT_DATA_BYTES(BT_DATA_UUID128_ALL, BT_UUID_AXS_VAL),
};


void error(void)
{
    dk_set_leds_state(DK_ALL_LEDS_MSK, DK_NO_LEDS_MSK);

    while (true) {
        /* Spin for ever */
        k_sleep(K_MSEC(1000));
    }
}

//static void system_power_off(void)
//{
//    //Shutdown power.
//#if defined(CONFIG_BOARD_TY52832_NRF52832)
//    NRF_POWER->SYSTEMOFF = 1;
//#endif

//}

static void get_time_stamp(float* f)
{
    uint32_t v = k_uptime_get_32();

    memcpy(f, &v, sizeof(float));
}


static void connected(struct bt_conn *conn, uint8_t err)
{
    char addr[BT_ADDR_LE_STR_LEN];

    if (err) {
        //LOG_ERR("Connection failed (err %u)", err);
        return;
    }

    bt_addr_le_to_str(bt_conn_get_dst(conn), addr, sizeof(addr));
    //LOG_INF("Connected %s", log_strdup(addr));

    current_conn = bt_conn_ref(conn);

    mtu = bt_gatt_get_mtu(current_conn);
    printf("MTU: %d", mtu);
}

static void disconnected(struct bt_conn *conn, uint8_t reason)
{
    char addr[BT_ADDR_LE_STR_LEN];

//    bt_addr_le_to_str(bt_conn_get_dst(conn), addr, sizeof(addr));
      bt_addr_le_to_str(bt_conn_get_dst(conn), addr, sizeof(addr));

    //LOG_INF("Disconnected: %s (reason %u)", log_strdup(addr), reason);

    if (current_conn) {
        bt_conn_unref(current_conn);
        current_conn = NULL;
    }

}

BT_CONN_CB_DEFINE(conn_callbacks) = {
	.connected        = connected,
	.disconnected     = disconnected,
};


static void bt_receive_cb(struct bt_conn *conn, const uint8_t *const data,
              uint16_t len)
{
//    int err;
//    char addr[BT_ADDR_LE_STR_LEN] = {0};
//    bt_addr_le_to_str(bt_conn_get_dst(conn), addr, ARRAY_SIZE(addr));
//   LOG_INF("Received data from: %s", log_strdup(addr));

//    printk("\n");
//    printf("len: %d\n", len);
    
    if(len == 2 ){

          uint8_t m_bt_data[len];

          memcpy(m_bt_data, data, len);
    
          uint8_t* m_command = &m_bt_data[0];
    
          size_t size = len / sizeof((uint8_t)m_command[0]);
          //size_t size = sizeof(m_command) / sizeof(m_command[0]);
    
//          printk("\n");
//          printf("m_type %d, m_command %d, %d\n", m_type, m_command[0], m_command[1]);
//          printf("size %d\n", size);
//          printk("\n");

          icm20649_write_command( m_command, size);
    }

}

static struct bt_axs_cb axs_cb = {
    .received = bt_receive_cb,
};

static void bt_adv_start(void)
{
    int err;



    err = bt_le_adv_start(BT_LE_ADV_CONN, ad, ARRAY_SIZE(ad), sd,
                  ARRAY_SIZE(sd));

    if (err) {
      //printk("Advertising failed to start (err %d)\n", err);
        return;
    }

//        printk("Advertising successfully started\n");


    
}

static void bt_init(void)
{
    int err = 0;

//    bt_conn_cb_register(&conn_callbacks);

    err = bt_enable(NULL);
    if (err) {
        error();
    }

    if (IS_ENABLED(CONFIG_SETTINGS)) {
        settings_load();
    }

    // BT Service init.
    err = bt_axs_init(&axs_cb);
    if (err) {
        //LOG_ERR("Failed to initialize UART service (err: %d)", err);
        return;
    }

}


static void button_changed(uint32_t button_state, uint32_t has_changed)
{

    if (has_changed & DK_BTN1_MSK) {

         //One shot timer. 3sec. button push.
//         k_timer_start(&button_timer, K_SECONDS(3), K_SECONDS(0));
    }
    
}

/**@brief Initializes buttons and LEDs, using the DK buttons and LEDs
 * library.
 */
static void buttons_leds_init(void)
{
    int err=0;

    err = dk_buttons_init(button_changed);
    if (err) {
        //LOG_ERR("Could not initialize buttons, err code: %d\n", err);
    }
        
    err = dk_leds_init();
    if (err) {
        //LOG_ERR("Could not initialize leds, err code: %d\n", err);
    }
}

/* long push */
//void button_timer_fn(struct k_timer *timer_id)
//{

//    uint32_t button_state = 0;
//    uint32_t has_changed = 0;
    
//    dk_read_buttons(&button_state, &has_changed);
//    uint32_t buttons = button_state & has_changed;
    
//    if(buttons){
//        dk_set_led(RUN_STATUS_LED, LED_OFF);

//        //printk("Goto power off.\r\n");
//        system_power_off();
        
//    }

//}


//static void timer_init(void) {
//    k_timer_init(&button_timer, button_timer_fn, NULL);
//}

//static void work_init(void)
//{
//
//    k_delayed_work_init(&leds_update_work, leds_update);
//
//}


void main(void)
{

    //LOG_INF("icm20648_dev sensor samples:\n");
    buttons_leds_init();
    k_sleep(K_MSEC(10));
    icm20649_setup();

//    timer_init();
//    k_sleep(K_MSEC(10));

    bt_init();

    dk_set_led(RUN_STATUS_LED, LED_OFF);

    bt_adv_start();
    
    while (true) {

            if(current_conn != NULL && bt_notify_enabled() == true){

                dk_set_led(RUN_STATUS_LED, LED_ON);

                get_time_stamp(&timeStamp);
                icm20649_sample_fetch();
                read_temperature(&temperature);

                uint8_t notify_data[sizeof(float)*12] = {0.0f};

                memcpy(&notify_data[sizeof(float)*0], accValueGlobal, sizeof(accValueGlobal));
                memcpy(&notify_data[sizeof(float)*3], gyrValueGlobal, sizeof(gyrValueGlobal));
                memcpy(&notify_data[sizeof(float)*6], quaValueGlobal, sizeof(quaValueGlobal));

                memcpy(&notify_data[sizeof(float)*10], &temperature, sizeof(float));
                memcpy(&notify_data[sizeof(float)*11], &timeStamp, sizeof(float));

                bt_axs_send(current_conn, (uint8_t *)notify_data, sizeof(notify_data));

                
                dk_set_led(RUN_STATUS_LED, LED_OFF);
                
            }

            dk_set_led(RUN_STATUS_LED, LED_OFF);
        
            /* Put CPU to idle to save power */
            k_cpu_idle();
    }
}

