/*
 * Copyright (c) 2018 Nordic Semiconductor ASA
 *
 * SPDX-License-Identifier: LicenseRef-BSD-5-Clause-Nordic
 */

#ifndef BT_AXS_H_
#define BT_AXS_H_

/**
 * @file
 * @defgroup bt_axs Axis Service(AXS) GATT Service
 * @{
 * @brief Axis Service (AXS) GATT Service API.
 */

#include <zephyr/types.h>
#include <zephyr/bluetooth/conn.h>
#include <zephyr/bluetooth/uuid.h>
#include <zephyr/bluetooth/gatt.h>

#ifdef __cplusplus
extern "C" {
#endif

//B882CEF5-95D7-4DD2-B5B3-07385E5E821F
/** @brief UUID of the AXS Service. **/
#define BT_UUID_AXS_VAL \
	BT_UUID_128_ENCODE(0xB8820001, 0x95D7, 0x4DD2, 0xB5B3, 0x07385E5E821F)

/** @brief UUID of the TX Characteristic. **/
#define BT_UUID_AXS_TX_VAL \
	BT_UUID_128_ENCODE(0xB8820003, 0x95D7, 0x4DD2, 0xB5B3, 0x07385E5E821F)

/** @brief UUID of the RX Characteristic. **/
#define BT_UUID_AXS_RX_VAL \
    BT_UUID_128_ENCODE(0xB8820002, 0x95D7, 0x4DD2, 0xB5B3, 0x07385E5E821F)

#define BT_UUID_AXS_SERVICE   BT_UUID_DECLARE_128(BT_UUID_AXS_VAL)
#define BT_UUID_AXS_RX        BT_UUID_DECLARE_128(BT_UUID_AXS_RX_VAL)
#define BT_UUID_AXS_TX        BT_UUID_DECLARE_128(BT_UUID_AXS_TX_VAL)

/** @brief Pointers to the callback functions for service events. */
struct bt_axs_cb {
	/** @brief Data received callback.
	 *
	 * The data has been received as a write request on the AXS RX
	 * Characteristic.
	 *
	 * @param[in] conn  Pointer to connection object that has received data.
	 * @param[in] data  Received data.
	 * @param[in] len   Length of received data.
	 */
	void (*received)(struct bt_conn *conn,
			 const uint8_t *const data, uint16_t len);

};

/**@brief Initialize the service.
 *
 * @details This function registers a GATT service with two characteristics,
 *          TX and RX. A remote device that is connected to this service
 *          can send data to the RX Characteristic. When the remote enables
 *          notifications, it is notified when data is sent to the TX
 *          Characteristic.
 *
 * @param[in] callbacks  Struct with function pointers to callbacks for service
 *                       events. If no callbacks are needed, this parameter can
 *                       be NULL.
 *
 * @retval 0 If initialization is successful.
 *           Otherwise, a negative value is returned.
 */
int bt_axs_init(struct bt_axs_cb *callbacks);

/**@brief Send data.
 *
 * @details This function sends data to a connected peer, or all connected
 *          peers.
 *
 * @param[in] conn Pointer to connection object, or NULL to send to all
 *                 connected peers.
 * @param[in] data Pointer to a data buffer.
 * @param[in] len  Length of the data in the buffer.
 *
 * @retval 0 If the data is sent.
 *           Otherwise, a negative value is returned.
 */
void bt_axs_send(struct bt_conn *conn, const uint8_t *data, uint16_t len);

/**@brief Get maximum data length that can be used for @ref bt_axs_send.
 *
 * @param[in] conn Pointer to connection Object.
 *
 * @return Maximum data length.
 */
//static inline uint32_t bt_axs_get_mtu(struct bt_conn *conn)
//{
//	/* According to 3.4.7.1 Handle Value Notification off the ATT protocol.
//	 * Maximum supported notification is ATT_MTU - 3 */
//	return bt_gatt_get_mtu(conn) - 3;
//}



bool bt_notify_enabled(void);




#ifdef __cplusplus
}
#endif

/**
 *@}
 */

#endif /* BT_AXS_H_ */
