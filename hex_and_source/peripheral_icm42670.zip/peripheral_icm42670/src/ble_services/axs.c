/*
 * Copyright (c) 2018 Nordic Semiconductor ASA
 *
 * SPDX-License-Identifier: LicenseRef-BSD-5-Clause-Nordic
 */

#include <zephyr/bluetooth/conn.h>
#include <zephyr/bluetooth/uuid.h>
#include <zephyr/bluetooth/gatt.h>

// #include <bluetooth/conn.h>
// #include <bluetooth/uuid.h>
// #include <bluetooth/gatt.h>

#include "axs.h"

//#include <logging/log.h>
//LOG_MODULE_REGISTER(bt_axs, CONFIG_BT_AXS_LOG_LEVEL);

#define NOTIFY_CUD "AxisValue"
#define WRITE_CUD  "Sensor config"

static bool notify_enabled;
static struct bt_axs_cb axs_cb;


static void axsc_ccc_cfg_changed(const struct bt_gatt_attr *attr,
				  uint16_t value)
{
      notify_enabled = (value == BT_GATT_CCC_NOTIFY);
}

static ssize_t on_receive(struct bt_conn *conn,
			  const struct bt_gatt_attr *attr,
			  const void *buf,
			  uint16_t len,
			  uint16_t offset,
			  uint8_t flags)
{

//	LOG_DBG("Received data, handle %d, conn %p",
//		attr->handle, conn);

    if (axs_cb.received) {
        axs_cb.received(conn, buf, len);
    }

	return len;
}

/* Service Declaration */
BT_GATT_SERVICE_DEFINE(axs_svc,
BT_GATT_PRIMARY_SERVICE(BT_UUID_AXS_SERVICE),
    BT_GATT_CHARACTERISTIC(BT_UUID_AXS_TX,
                         BT_GATT_CHRC_NOTIFY,
                         BT_GATT_PERM_READ,
                         NULL, NULL, NULL),

    BT_GATT_CUD(NOTIFY_CUD, BT_GATT_PERM_READ),

    BT_GATT_CCC(axsc_ccc_cfg_changed, BT_GATT_PERM_READ | BT_GATT_PERM_WRITE),

    BT_GATT_CHARACTERISTIC(BT_UUID_AXS_RX,
                         BT_GATT_CHRC_WRITE |
                         BT_GATT_CHRC_WRITE_WITHOUT_RESP,
                         BT_GATT_PERM_READ | BT_GATT_PERM_WRITE,
                         NULL, on_receive, NULL),

    BT_GATT_CUD(WRITE_CUD, BT_GATT_PERM_READ),
                       
);

int bt_axs_init(struct bt_axs_cb *callbacks)
{
    if (callbacks) {
        axs_cb.received = callbacks->received;
    }

    return 0;
}

void bt_axs_send(struct bt_conn *conn, const uint8_t *data, uint16_t len)
{

    bt_gatt_notify(conn, &axs_svc.attrs[1], data, len);
}


bool bt_notify_enabled(void)
{
    return notify_enabled;
}
