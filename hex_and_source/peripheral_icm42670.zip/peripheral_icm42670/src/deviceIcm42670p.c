
#include <stdint.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>

//#include <logging/log.h>
#include <zephyr/logging/log.h>

#include <stdint.h>
#include <stdio.h>

//#include <device.h>
#include <zephyr/device.h>
#include <zephyr/types.h>
//#include <sys/util.h>
//#include <sys/slist.h>
#include <zephyr/sys/util.h>
#include <zephyr/sys/slist.h>
#include <zephyr/drivers/i2c.h>
//#include <drivers/i2c.h>
//#include <zephyr.h>
#include <zephyr/zephyr.h>

#include <math.h>

#include "invn_algo_agm.h"
//#include "Invn/EmbUtils/Message.h"
#include "RingBuffer.h"

#include "deviceIcm42670p.h"


extern float accValueGlobal[3];
extern float gyrValueGlobal[3];
extern float quaValueGlobal[4];
extern float temperature;


#define RAD_TO_DEG(rad) ((float)rad * 57.2957795131)

RINGBUFFER_VOLATILE(timestamp_buffer_icm, 64, uint64_t);

/* --------------------------------------------------------------------------------------
 *  Static and extern variables
 * -------------------------------------------------------------------------------------- */

/* IMU driver object */
static struct inv_imu_device icm_driver;

/*
 * IMU mounting matrix
 * Coefficients are coded as Q30 integer
 */
#if (SM_BOARD_REV == SM_REVB_DB) /* when DB or EVB are used */
static int32_t icm_mounting_matrix[9] = {  0,     -(1<<30), 0,
                                          (1<<30), 0,       0,
                                           0,      0,      (1<<30) };
#else /* For SmartMotion */
static int32_t icm_mounting_matrix[9] = {(1<<30),  0,       0,
                                          0,      (1<<30),  0,
                                          0,       0,      (1<<30)};
#endif

/* Full Scale Range */
//#if IS_HIGH_RES_MODE
//    static const int32_t acc_fsr = 16;   /* +/- 16g */
//    static const int32_t gyr_fsr = 2000; /* +/- 2000dps */
//#else
//    static int32_t acc_fsr = 4;        /* +/- 4g */
//    static int32_t gyr_fsr = 2000;     /* +/- 2000dps */
//#endif

static int32_t acc_fsr = 16;        /* +/- 16 */
static int32_t gyr_fsr = 2000;     /* +/- 2000dps */


static InvnAlgoAGMInput input;
static InvnAlgoAGMOutput output;

/* Accelerometer gyroscope and magnetometer biases */
static int32_t acc_bias[3];
static int32_t gyr_bias[3];
static int32_t mag_bias[3];

/* Accelerometer gyroscope and magnetometer accuracies */
static int32_t acc_accuracy;
static int32_t gyr_accuracy;
static int32_t mag_accuracy;

/* Bias previously stored in flash */
typedef struct sensor_biases {
    int32_t bias_q16[3];
    uint8_t is_saved;
} sensor_biases_t;

/* --------------------------------------------------------------------------------------
 *  static function declaration
 * -------------------------------------------------------------------------------------- */
static void apply_mounting_matrix(const int32_t matrix[9], int32_t raw[3]);

static int gyro_fsr_dps_to_bitfield(int32_t fsr);
static int accel_fsr_g_to_bitfield(int32_t fsr);

void notify_data(uint64_t time, InvnAlgoAGMInput input, InvnAlgoAGMOutput output);

/* IMU driver object */
static struct inv_imu_device icm_driver;

/* Zephyr I2C Instance */
static struct device *i2c_dev;

static void twi_init(void)
{
    uint32_t i2c_cfg = I2C_SPEED_SET(I2C_SPEED_STANDARD) | I2C_MODE_MASTER;
    //const char dev_name[] = "I2C_0";
    i2c_dev = DEVICE_DT_GET(DT_NODELABEL(i2c0));//device_get_binding(dev_name);

    if (i2c_dev == NULL) {
//        printk("Failed to get pointer to i2c device\n");
        return ;
    }else{
        i2c_configure(i2c_dev, i2c_cfg);
    }
    
//    printk("i2c init done.\n");

}


static int twi_read_reg(uint8_t reg, uint8_t *data, uint32_t length)
{

// --- Default ---
    i2c_burst_read(i2c_dev, 0x68, reg, data, length);
//--- ---

    return 0;
}

static int twi_write_reg(uint8_t reg, uint8_t *data, uint32_t length)
{

// --- Default ---
    uint8_t tx_data[(length+1)];

    tx_data[0] = reg;
    memcpy(&tx_data[1], data, length);
    i2c_write(i2c_dev, tx_data, sizeof(tx_data), 0x68);
//--- ---
       
    return 0;
}


/* Host Serif object definition for SPI ***************************************/

static int idd_io_hal_init(void)
{
    twi_init();
    return 0;
}

static int idd_io_hal_read_reg(struct inv_imu_serif *serif, uint8_t reg, uint8_t * rbuffer, uint32_t rlen)
{
    twi_read_reg(reg, rbuffer, rlen);
    return 0;
}

static int idd_io_hal_write_reg(struct inv_imu_serif *serif, uint8_t reg, const uint8_t * wbuffer, uint32_t wlen)
{
    twi_write_reg(reg, (uint8_t *)wbuffer, wlen);
    return 0;
}




/* --------------------------------------------------------------------------------------
 *  Functions definition
 * -------------------------------------------------------------------------------------- */

int setup_imu_device(struct inv_imu_serif *icm_serif)
{
    int rc = 0;
    uint8_t who_am_i;

    /* Init device */
    rc = inv_imu_init(&icm_driver, icm_serif, imu_callback);
    if (rc != INV_ERROR_SUCCESS) {
//        INV_MSG(INV_MSG_LEVEL_ERROR, "Failed to initialize IMU!");
        return rc;
    }
    
    /* Check WHOAMI */
    rc = inv_imu_get_who_am_i(&icm_driver, &who_am_i);
    if (rc != INV_ERROR_SUCCESS) {
 //       INV_MSG(INV_MSG_LEVEL_ERROR, "Failed to read whoami!");
        return rc;
    }
    

//    if (who_am_i != ICM_WHOAMI) {
    if(who_am_i != ICM42607P_WHOAMI) {
        // INV_MSG(INV_MSG_LEVEL_ERROR, "Bad WHOAMI value!");
        // INV_MSG(INV_MSG_LEVEL_ERROR, "Read 0x%02x, expected 0x%02x", who_am_i, ICM_WHOAMI);
        return INV_ERROR;
    }
    
    RINGBUFFER_CLEAR(&timestamp_buffer_icm);

    return rc;
}


int configure_imu_device(void)
{
    int rc = 0;

//    rc |= inv_flash_manager_init(); 
    
//#if IS_HIGH_RES_MODE
//    rc |= inv_imu_enable_high_resolution_fifo(&icm_driver);
//#else
    rc |= inv_imu_set_accel_fsr(&icm_driver, (ACCEL_CONFIG0_FS_SEL_t)accel_fsr_g_to_bitfield(acc_fsr));
    rc |= inv_imu_set_gyro_fsr(&icm_driver,  (GYRO_CONFIG0_FS_SEL_t) gyro_fsr_dps_to_bitfield(gyr_fsr));
//#endif
    
    rc |= inv_imu_set_accel_frequency(&icm_driver, ACCEL_FREQ);
    rc |= inv_imu_set_gyro_frequency(&icm_driver,  GYRO_FREQ);

//#if IS_LOW_NOISE_MODE
    rc |= inv_imu_enable_accel_low_noise_mode(&icm_driver);
//#else
//    rc |= inv_imu_enable_accel_low_power_mode(&icm_driver);
//#endif

    rc |= inv_imu_enable_gyro_low_noise_mode(&icm_driver);
    
    return rc;
}


/*
 * This function clears biases and accuracies.
 */
int reset_agm_biases(void)
{
    memset(acc_bias, 0, sizeof(acc_bias));
    memset(gyr_bias, 0, sizeof(gyr_bias));
    memset(mag_bias, 0, sizeof(mag_bias));
    acc_accuracy = 0;
    gyr_accuracy = 0;
    mag_accuracy = 0;

    return 0;
}


/*
 * This function initializes biases and accuracies for accelerometer, gyroscope and magnetometer.
 */
int init_agm_biases(void)
{
    /* Retrieve stored biases */
    // if (retrieve_stored_biases_from_flash(acc_bias, gyr_bias, mag_bias) == 0) {
    //     printk( "   Biases loaded from flash:");
    //     printk( "    - Accel: [%f %f %f]g",
    //         (float)acc_bias[0]/(1<<16), (float)acc_bias[1]/(1<<16), (float)acc_bias[2]/(1<<16));
    //     printk( "    - Gyro:  [%f %f %f]dps",
    //         (float)gyr_bias[0]/(1<<16), (float)gyr_bias[1]/(1<<16), (float)gyr_bias[2]/(1<<16));
    //     printk( "    - Mag:   [%f %f %f]uT",
    //         (float)mag_bias[0]/(1<<16), (float)mag_bias[1]/(1<<16), (float)mag_bias[2]/(1<<16));
        
    //     acc_accuracy = 3;
    //     gyr_accuracy = 2;
    //     mag_accuracy = 1;
    // } else {
        printk( "   No bias values retrieved");
        memset(acc_bias,0,sizeof(acc_bias));
        memset(gyr_bias,0,sizeof(gyr_bias));
        memset(mag_bias,0,sizeof(mag_bias));
        acc_accuracy = 0;
        gyr_accuracy = 0;
        mag_accuracy = 0;
    //}

    return 0;
}

int init_agm_algo(void)
{
    int rc = 0;
    InvnAlgoAGMConfig config;

    memset(&input,  0, sizeof(input));
    memset(&output, 0, sizeof(output));
    memset(&config, 0, sizeof(config));

    // config.acc_bias_q16 = output.acc_bias_q16;
    // config.gyr_bias_q16 = output.gyr_bias_q16;
    // config.mag_bias_q16 = output.mag_bias_q16;
    
    /* FSR configurations */
    config.acc_fsr = acc_fsr;
    config.gyr_fsr = gyr_fsr;

    config.acc_odr_us = odr_bitfield_to_us(ACCEL_FREQ);
    config.gyr_odr_us = odr_bitfield_to_us(GYRO_FREQ);

    /* Temperature sensor configuration */
//#if IS_HIGH_RES_MODE
//    config.temp_sensitivity = (1 << 30) / 128; // high-res;
//    config.temp_offset = 25 << 16;
//#else
    config.temp_sensitivity = (1 << 30) / 2;
    config.temp_offset = 25 << 16;
//#endif
//
//#if USE_MAG
//    config.mag_sc_q16 = 9830;//0.15
//    config.mag_odr_us = MAG_ODR_US;
//#else
    config.mag_bias_q16 = NULL;
//#endif
    
    config.acc_bias_q16 = acc_bias;
    config.gyr_bias_q16 = gyr_bias;
    config.mag_bias_q16 = mag_bias;
    config.acc_accuracy = acc_accuracy;
    config.gyr_accuracy = gyr_accuracy;
    config.mag_accuracy = mag_accuracy;

    /* Initialize algorithm */
    rc |= invn_algo_agm_init(&config);

    return rc;
}

int get_imu_data(void)
{
    /*
     * Extract packets from FIFO. Callback defined at init time (i.e. 
     * imu_callback) will be called for each valid packet extracted from 
     * FIFO.
     */
    return inv_imu_get_data_from_fifo(&icm_driver);
}


void imu_callback(inv_imu_sensor_event_t *event)
{
    uint64_t irq_timestamp = 0;

    /*
     * First, let's process the sensor event timestamp.
     * Extract the timestamp that was buffered when current packet IRQ fired. See 
     * ext_interrupt_cb() in main.c for more details.
     * As timestamp buffer is filled in interrupt handler, we should pop it with
     * interrupts disabled to avoid any concurrent access.
     */

    // inv_disable_irq();
      if (!RINGBUFFER_VOLATILE_EMPTY(&timestamp_buffer_icm)) {
          RINGBUFFER_VOLATILE_POP(&timestamp_buffer_icm, &irq_timestamp);
      }
    // inv_enable_irq();

    // input.mask = 0;

    /*
     * Retrieve accel and gyro data
     */
    if (event->sensor_mask & (1 << INV_SENSOR_ACCEL)) {
// #if IS_HIGH_RES_MODE
//         input.sRacc_data[0] = (((int32_t)event->accel[0] << 4)) | event->accel_high_res[0];
//         input.sRacc_data[1] = (((int32_t)event->accel[1] << 4)) | event->accel_high_res[1];
//         input.sRacc_data[2] = (((int32_t)event->accel[2] << 4)) | event->accel_high_res[2];
// #else
        input.sRacc_data[0] = (int32_t)event->accel[0] << 4;
        input.sRacc_data[1] = (int32_t)event->accel[1] << 4;
        input.sRacc_data[2] = (int32_t)event->accel[2] << 4;
//#endif
        apply_mounting_matrix(icm_mounting_matrix, input.sRacc_data);
        input.mask |= INVN_ALGO_AGM_INPUT_MASK_ACC;
    }

    if (event->sensor_mask & (1 << INV_SENSOR_GYRO)) {
// #if IS_HIGH_RES_MODE    
//         input.sRgyr_data[0] = (((int32_t)event->gyro[0] << 4)) | event->gyro_high_res[0];
//         input.sRgyr_data[1] = (((int32_t)event->gyro[1] << 4)) | event->gyro_high_res[1];
//         input.sRgyr_data[2] = (((int32_t)event->gyro[2] << 4)) | event->gyro_high_res[2];
// #else
        input.sRgyr_data[0] = (int32_t)event->gyro[0] << 4;
        input.sRgyr_data[1] = (int32_t)event->gyro[1] << 4;
        input.sRgyr_data[2] = (int32_t)event->gyro[2] << 4;
//#endif
        apply_mounting_matrix(icm_mounting_matrix, input.sRgyr_data);
        input.mask |= INVN_ALGO_AGM_INPUT_MASK_GYR;
    }

    input.sRtemp_data = event->temperature;
    input.sRimu_time_us = irq_timestamp;

    /* Process the AgmFusion Algo */
    invn_algo_agm_process(&input, &output);
    
//    store_biases();

    /* Notify data to frontend for print of at least one of the input was provided */
    if (input.mask != 0) {
        notify_data(input.sRimu_time_us, input, output);
    }

}


/*
 * This function initializes MCU on which this software is running.
 * It configures:
 *   - a UART link used to print some messages
 *   - interrupt priority group and GPIOs so that MCU can receive interrupts from both
 *     IMU and Akm09915
 *   - a microsecond timer requested by IMU driver to compute some delay
 *   - a microsecond timer used to get some timestamps
 *   - a microsecond timer used to periodically starts magneto data acquisition
 *   - a serial link to communicate from MCU to IMU
 *   - a serial link to communicate from MCU to Akm09915
 */
int inv_imu_setup_mcu(void)
{
    int rc = 0;
    
    idd_io_hal_init();
    

    printk("###################\n");
    printk("#   Example AGM   #\n");
    printk("###################\n");
    
    struct inv_imu_serif icm_serif;

    /* Initialize serial interface between MCU and IMU */
    icm_serif.context   = 0;        /* no need */
    icm_serif.read_reg  = idd_io_hal_read_reg;
    icm_serif.write_reg = idd_io_hal_write_reg;
    icm_serif.max_read  = 1024*32;  /* maximum number of bytes allowed per serial read */
    icm_serif.max_write = 1024*32;  /* maximum number of bytes allowed per serial write */
    icm_serif.serif_type = UI_I2C;
    
    rc |= setup_imu_device(&icm_serif);
    rc |= init_agm_biases();
    rc |= init_agm_algo();
    rc |= configure_imu_device();

    return rc;
}

static void apply_mounting_matrix(const int32_t matrix[9], int32_t raw[3])
{
    unsigned i;
    int64_t data_q30[3];
    
    for (i = 0; i < 3; i++) {
        data_q30[i] =  ((int64_t)matrix[3 * i + 0] * raw[0]);
        data_q30[i] += ((int64_t)matrix[3 * i + 1] * raw[1]);
        data_q30[i] += ((int64_t)matrix[3 * i + 2] * raw[2]);
    }
    raw[0] = (int32_t)(data_q30[0] >> 30);
    raw[1] = (int32_t)(data_q30[1] >> 30);
    raw[2] = (int32_t)(data_q30[2] >> 30);
}

uint32_t odr_bitfield_to_us(uint32_t odr_bitfield)
{
    switch ((GYRO_CONFIG0_ODR_t)odr_bitfield) {
        case GYRO_CONFIG0_ODR_1600_HZ: return 625;
        case GYRO_CONFIG0_ODR_800_HZ:  return 1250;
        case GYRO_CONFIG0_ODR_400_HZ:  return 2500;
        case GYRO_CONFIG0_ODR_200_HZ:  return 5000;
        case GYRO_CONFIG0_ODR_100_HZ:  return 10000;
        case GYRO_CONFIG0_ODR_50_HZ:   return 20000;
        default:                       return 640000;
    }
}

//#if !IS_HIGH_RES_MODE
static int gyro_fsr_dps_to_bitfield(int32_t fsr)
{
    switch (fsr) {
    case 250:  return GYRO_CONFIG0_FS_SEL_250dps;
    case 500:  return GYRO_CONFIG0_FS_SEL_500dps;
    case 1000: return GYRO_CONFIG0_FS_SEL_1000dps;
    case 2000: return GYRO_CONFIG0_FS_SEL_2000dps;
    default:   return -1;
    }
}

static int accel_fsr_g_to_bitfield(int32_t fsr)
{
    switch (fsr) {
    case 2:  return ACCEL_CONFIG0_FS_SEL_2g;
    case 4:  return ACCEL_CONFIG0_FS_SEL_4g;
    case 8:  return ACCEL_CONFIG0_FS_SEL_8g;
    case 16: return ACCEL_CONFIG0_FS_SEL_16g;
    default: return -1;
    }
}
//#endif

static void fixedpoint_to_float(const int32_t *in, float *out, const uint8_t fxp_shift, const uint8_t dim)
{
    int i;
    float scale = 1.f / (1 << fxp_shift);

    for (i = 0; i < dim; i++)
        out[i] = scale * in[i];
}

static void quaternions_to_angles(const float quat[4], float angles[3])
{
    const float RAD_2_DEG = (180.f/3.14159265358979f);
    float rot_matrix[9];

    // quaternion to rotation matrix
    const float dTx  = 2.0f * quat[1];
    const float dTy  = 2.0f * quat[2];
    const float dTz  = 2.0f * quat[3];
    const float dTwx = dTx  * quat[0];
    const float dTwy = dTy  * quat[0];
    const float dTwz = dTz  * quat[0];
    const float dTxx = dTx  * quat[1];
    const float dTxy = dTy  * quat[1];
    const float dTxz = dTz  * quat[1];
    const float dTyy = dTy  * quat[2];
    const float dTyz = dTz  * quat[2];
    const float dTzz = dTz  * quat[3];

    rot_matrix[0] = 1.0f - (dTyy + dTzz);
    rot_matrix[1] = dTxy - dTwz;
    rot_matrix[2] = dTxz + dTwy;
    rot_matrix[3] = dTxy + dTwz;
    rot_matrix[4] = 1.0f - (dTxx + dTzz);
    rot_matrix[5] = dTyz - dTwx;
    rot_matrix[6] = dTxz - dTwy;
    rot_matrix[7] = dTyz + dTwx;
    rot_matrix[8] = 1.0f - (dTxx + dTyy);

    angles[0] = atan2f(-rot_matrix[3], rot_matrix[0])*RAD_2_DEG;
    angles[1] = atan2f(-rot_matrix[7], rot_matrix[8])*RAD_2_DEG;
    angles[2] = asinf(-rot_matrix[6]) * RAD_2_DEG;

    if (angles[0] < 0.f) {
        angles[0] += 360.f;
    }
}

void notify_data(uint64_t time, InvnAlgoAGMInput input, InvnAlgoAGMOutput output)
{
    (void)time;
    float acc_g[3], acc_bias[3];
    float gyr_dps[3], gyr_bias[3];
    float temp;
    float grv_quat[4], angles_deg_grv[3];
    float gravity[3], linear_acc[3];

        
    /* Convert data to float before send it to the terminal */
    fixedpoint_to_float( output.acc_cal_q16,            acc_g,       16, 3);
    fixedpoint_to_float( output.acc_bias_q16,           acc_bias,    16, 3);
    fixedpoint_to_float( output.gyr_cal_q16,            gyr_dps,     16, 3);
    fixedpoint_to_float( output.gyr_bias_q16,           gyr_bias,    16, 3);
    fixedpoint_to_float( &output.temp_degC_q16,         &temp,       16, 1);
    fixedpoint_to_float( output.grv_quat_q30,           grv_quat,    30, 4);
    fixedpoint_to_float( output.gravity_q16,            gravity,     16, 3);
    fixedpoint_to_float( output.linear_acc_q16,         linear_acc,  16, 3);
    quaternions_to_angles(grv_quat, angles_deg_grv);

    
    
    accValueGlobal[0] = acc_g[0];
    accValueGlobal[1] = acc_g[1];
    accValueGlobal[2] = acc_g[2];

    gyrValueGlobal[0] = gyr_dps[0];
    gyrValueGlobal[1] = gyr_dps[1];
    gyrValueGlobal[2] = gyr_dps[2];

    quaValueGlobal[0] = grv_quat[0];
    quaValueGlobal[1] = grv_quat[1];
    quaValueGlobal[2] = grv_quat[2];
    quaValueGlobal[3] = grv_quat[3];

    temperature = temp;

    
    
    
//        /* Print intputs */
////        if (data_to_print & MASK_PRINT_INPUT_DATA) {
//            /* IMU data */
//            printk( "%lld: INPUT  RAcc=[%d, %d, %d] RGyr=[%d, %d, %d] Rtemp=[%d]",
//                input.sRimu_time_us,
//                input.sRacc_data[0] >> 4, input.sRacc_data[1] >> 4, input.sRacc_data[2] >> 4,
//                input.sRgyr_data[0] >> 4, input.sRgyr_data[1] >> 4, input.sRgyr_data[2] >> 4,
//                (int32_t)input.sRtemp_data
//                );
////        }
//
//        /* Print outputs */
////        if (data_to_print & MASK_PRINT_ACC_DATA) {
//            printk( "%lld: OUTPUT Acc=[%.3f, %.3f, %.3f]g AccBias=[%.3f, %.3f, %.3f]mg Accuracy=%d",
//                input.sRimu_time_us,
//                acc_g[0], acc_g[1], acc_g[2],
//                acc_bias[0]*1000, acc_bias[1]*1000, acc_bias[2]*1000,
//                (int32_t)output.acc_accuracy_flag
//                );
//
////        }
//
////        if (data_to_print & MASK_PRINT_GYR_DATA) {
//            printk( "%lld: OUTPUT Gyr=[%.3f, %.3f, %.3f]dps GyrBias=[%.3f, %.3f, %.3f]dps Temp=[%.2f]C Accuracy=%d",
//                input.sRimu_time_us,
//                gyr_dps[0],  gyr_dps[1],  gyr_dps[2],
//                gyr_bias[0], gyr_bias[1], gyr_bias[2],
//                temp,
//                (int32_t)output.gyr_accuracy_flag
//                );
//
//
////        }
//
//
//
////        if (data_to_print & MASK_PRINT_6AXIS_DATA) {
//            printk( "%lld: OUTPUT 6Axis=[%f, %f, %f, %f]",
//                input.sRimu_time_us,
//                grv_quat[0], grv_quat[1], grv_quat[2], grv_quat[3]
//                );
//
//
//            printk( "%lld: OUTPUT Euler6Axis=[%.2f, %.2f, %.2f]deg",
//                input.sRimu_time_us,
//                angles_deg_grv[0], angles_deg_grv[1], angles_deg_grv[2]
//                );
////        }
//
////        if (data_to_print & MASK_PRINT_GRAVITY_DATA) {
//            printk( "%lld: OUTPUT Gravity=[%f, %f, %f] Accuracy=%d",
//                input.sRimu_time_us,
//                gravity[0], gravity[1], gravity[2],
//                output.acc_accuracy_flag);
////        }
////        if (data_to_print & MASK_PRINT_LINEARACC_DATA) {
//            printk( "%lld: OUTPUT LinearAcc=[%f, %f, %f] Accuracy=%d",
//                input.sRimu_time_us,
//                linear_acc[0], linear_acc[1], linear_acc[2],
//                output.acc_accuracy_flag);
////        }
//

        /* Print carriage return to ease reading, only if some data are printed */
//        if (data_to_print) {
//            printk( "");
//        }

    // }
    // iter_algo++;
}

void inv_imu_sleep_us(int us) {
    k_sleep(K_USEC(us));
}

static volatile uint32_t overflows = 0;
uint64_t inv_imu_get_time_us(void) {
    
    uint64_t ticks = (uint64_t)((uint64_t)overflows << (uint64_t)24) | (uint64_t)k_uptime_get();
    return (ticks * 1000000) / 32768;
    
}

void inv_imu_write_command(uint8_t* command, uint8_t command_len){

    //Accel FSR
    switch(command[0]){
        case 0:
          acc_fsr = 2;
          break;
        case 1:
          acc_fsr = 4;
          break;
        case 2:
          acc_fsr = 8;
          break;
        case 3:
          acc_fsr = 16;
          break;
        default:
          acc_fsr = 2;
          break;
    }

    //Gyro FSR
    switch(command[1]){
        case 0:
          gyr_fsr = 250;
          break;
        case 1:
          gyr_fsr = 500;
          break;
        case 2:
          gyr_fsr = 1000;
          break;
        case 3:
          gyr_fsr = 2000;
          break;
        default:
          gyr_fsr = 250;
          break;
    }
  
//        printf("Accel FSR: %d\n", cfg_acc_fsr);
//        printf("Gyro  FSR: %d\n", cfg_gyr_fsr);

    inv_imu_set_accel_fsr(&icm_driver, (ACCEL_CONFIG0_FS_SEL_t)accel_fsr_g_to_bitfield(acc_fsr));
    inv_imu_set_gyro_fsr(&icm_driver,  (GYRO_CONFIG0_FS_SEL_t) gyro_fsr_dps_to_bitfield(gyr_fsr));

}

uint8_t inv_imu_current_acc_fsr(void){
    return acc_fsr;
}
uint8_t inv_imu_current_gyr_fsr(void){
    return gyr_fsr;
}
