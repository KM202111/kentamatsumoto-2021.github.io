//
//  Header.h
//  
//
//  Created by hoehoe on 2021/10/18.
//

#ifndef Header_h
#define Header_h

#include "inv_imu_driver.h"

#include <stdint.h>

/* 
 * Select communication link between SmartMotion and IMU 
 */
#define SERIF_TYPE           UI_I2C


/*
 * Set this define to 0 to disable mag support
 * Recommended value: 1
 */
#define USE_MAG              0

/*
 * Set power mode flag
 * Set this flag to run example in low-noise mode.
 * Reset this flag to run example in low-power mode.
 * Note : low-noise mode is not available with sensor data frequencies less than 12.5Hz.
 */
//#define IS_LOW_NOISE_MODE    1

/*
 * Accelerometer and gyroscope frequencies.
 * Possible values (same for accel, replace "GYRO" with "ACCEL"): 
 * - GYRO_CONFIG0_ODR_800_HZ  (800 Hz)
 * - GYRO_CONFIG0_ODR_400_HZ (400 Hz)
 * - GYRO_CONFIG0_ODR_200_HZ (200 Hz)
 * - GYRO_CONFIG0_ODR_100_HZ (100 Hz)
 * - GYRO_CONFIG0_ODR_50_HZ (50 Hz)
 */
#define GYRO_FREQ            GYRO_CONFIG0_ODR_100_HZ
#define ACCEL_FREQ           ACCEL_CONFIG0_ODR_100_HZ

/*
 * Magnetometer output data rate in us
 * Only supported value: 10000 us (100 Hz)
 * Possible values:
 * - 5000  (200 Hz)
 * - 10000 (100 Hz)
 * - 20000 (50 Hz)
 * Note: Not use if `USE_MAG` is set to 0
 */
//#define MAG_ODR_US           10000

/*
 * Select Fifo resolution Mode (default is low resolution mode)
 * Low resolution mode : 16 bits data format
 * High resolution mode : 20 bits data format
 * Warning: Enabling High Res mode will force FSR to 16g and 2000dps
 */
//#define IS_HIGH_RES_MODE     0

/*
 * Enum for possible commands from user
 */
typedef enum {
	ALGORITHM_RESET       = 0,
} inv_algo_commands;

/**
 * \brief This function is in charge of reseting and initializing IMU device. It should
 * be successfully executed before any access to IMU device.
 * 
 * \param[in] icm_serif : Serial interface object.
 * \return 0 on success, negative value on error.
 */
int setup_imu_device(struct inv_imu_serif *icm_serif);

/**
 * \brief This function configures the device in order to output gyro and accelerometer.
 *
 * It initializes clock calibration module (this will allow to extend the 16 bits 
 * timestamp produced by IMU to a 64 bits timestamp).
 * Then function sets full scale range and frequency for both accel and gyro and it 
 * starts them in the requested power mode. (note that low-power mode is not available 
 * for gyroscope in IMU).
 *
 * \return 0 on success, negative value on error.
 */
int configure_imu_device(void);

/**
 * \This function clears biases and accuracies.
 *
 * \return 0 on success, negative value on error.
 */
int reset_agm_biases(void);

/**
 * \brief This function initializes biases and accuracies for accelerometer, gyroscope and magnetometer.
 *
 * \return 0 on success, negative value on error.
 */
int init_agm_biases(void);

/**
 * \brief This function initializes the AGM algorithm.
 *
 * \return 0 on success, negative value on error.
 */
int init_agm_algo(void);

/**
 * \brief This function extracts data from the IMU FIFO.
 *
 * The function just calls IMU driver function inv_imu_get_data_from_fifo.
 * But note that for each packet extracted from FIFO, a user defined function is called to 
 * allow custom handling of each packet. In this example custom packet handling function
 * is imu_callback.
 *
 * \return 0 on success, negative value on error.
 */
int get_imu_data(void);

/**
 * \brief This function is the custom handling packet function.
 *
 * It is passed in parameter at driver init time and it is called by 
 * inv_imu_get_data_from_fifo function each time a new valid packet is extracted 
 * from FIFO.
 * In this implementation, function extends packet timestamp from 16 to 64 bits and then
 * process data from packet and print them on UART.
 *
 * \param[in] event structure containing sensor data from one packet
 */
void imu_callback(inv_imu_sensor_event_t *event);

/*!
 * \brief Converter function from period (in usec) to frequency (in Hz)
 */
uint32_t period_us_to_frequency(const uint32_t period_us);


/**
 * \brief Helper to convert bitfield to odr value
 * \param[in] odr_bitfield enum containing bitfield
 *
 */
uint32_t odr_bitfield_to_us(uint32_t odr_bitfield);



/**
 * 
 * Added functions.
 * 
 */

int inv_imu_setup_mcu(void);
void inv_imu_sleep_us(int us);
uint64_t inv_imu_get_time_us(void);
void inv_imu_write_command(uint8_t* command, uint8_t command_len);
uint8_t inv_imu_current_acc_fsr(void);
uint8_t inv_imu_current_gyr_fsr(void);

#endif /* Header_h */
