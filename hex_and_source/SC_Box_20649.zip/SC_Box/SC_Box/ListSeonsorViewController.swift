//
//  ListSeonsorViewController.swift
//  AbilityTrainer
//
//  Created by hoehoe on 2019/09/09.
//  Copyright © 2019 chocbanana. All rights reserved.
//

import UIKit

class ListSeonsorViewController: UITableViewController {

    var dataSourceList:Array<AdvPeripheral>! = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
        
        self.tableView.delegate = self;
        self.tableView.dataSource = self;
        
        NotificationCenter.default.addObserver(self, selector: #selector(notifyList(notification:)), name: NSNotification.Name("notifyList"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(notifyListZero(notification:)), name: NSNotification.Name("notifyListZero"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(notifyConnect(notification:)), name: NSNotification.Name("notifyConnect"), object: nil)
        
    }
    
    @objc func notifyConnect(notification:Notification) {

        DispatchQueue.main.async {
            self.dismiss(animated: true) {
                
            }
        }
        
    }
    
    @objc func notifyList(notification: Notification){
        let arr:Array<AdvPeripheral>! = notification.userInfo?["sensor"] as? Array<AdvPeripheral>
        dataSourceList = arr.sorted { $0.identifier < $1.identifier }
        
        DispatchQueue.main.async {
            self.tableView.reloadData()
        }
    }
    
    @objc func notifyListZero(notification: Notification){
        DispatchQueue.main.async {
            self.dismiss(animated: true) {
                
            }
        }
    }
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return dataSourceList.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: "advPeripheralCell")
            
        //tableView.dequeueReusableCell(withIdentifier: "advPeripheralCell", for: indexPath)

        // Configure the cell...
        if cell == nil {
            cell = UITableViewCell.init(style: .value2, reuseIdentifier: "advPeripheralCell")
        }
        
        let adv:AdvPeripheral = dataSourceList[indexPath.row]
        
        cell?.textLabel?.text = adv.name
        cell?.detailTextLabel?.text = String( adv.rssi.intValue ) //"RSSI: " + String( adv.rssi.intValue )
        
        return cell!
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let manager:BTManager = BTManager.shared
//        manager.isConnected = true
        let p:AdvPeripheral = self.dataSourceList[indexPath.row]
        
//        let userDefaults = UserDefaults.standard
//        userDefaults.set(p.identifier, forKey: "identifier")

        manager.connect(peripheral: p.peripheral)
    }

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
