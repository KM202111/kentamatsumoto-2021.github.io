//
//  ViewController.swift
//  SC_Box
//
//  Created by hoehoe on 2019/10/26.
//  Copyright © 2019 chocbanana. All rights reserved.
//

import UIKit

class ViewController: UIViewController, BT_ManagerDelegate, BT_PeripheralDelegate {
    
    func sizeof <T> (_ : T.Type) -> Int
    {
        return (MemoryLayout<T>.size)
    }
    
    func sizeof <T> (_ : T) -> Int
    {
        return (MemoryLayout<T>.size)
    }
    
    func sizeof <T> (_ value : [T]) -> Int
    {
        return (MemoryLayout<T>.size * value.count)
    }
    
    func foundPeripheralDelegate(btPeripheral: BT_Peripheral) {
        self.btPeripheral = btPeripheral
        self.btPeripheral?.delegate = self
    }
    
    func lostPeripheralDelegate() {
        self.btPeripheral = nil
    }
    
    func peripheral_Data(value: NSData) {
        
        var bleValue:Array<Float> = [0.0, 0.0, 0.0, //Accel
        0.0, 0.0, 0.0, //Gyro
        0.0, 0.0, 0.0, //Mag
        0.0, 0.0, 0.0, 0.0] //Quaternion
        //0.0, 0.0, 0.0] //Yaw, Pitch, Roll
        
        value.getBytes(&bleValue, range: NSMakeRange(0, sizeof(bleValue)))
        
        if isAccel {
            
            var accel:Array<Float> = [0.0, 0.0, 0.0]
            accel[0] = bleValue[0]
            accel[1] = bleValue[1]
            accel[2] = bleValue[2]
            
            let accelValue:SIMD3<Double> = [ Double(accel[0]), Double(accel[1]), Double(accel[2]) ]
            
                DispatchQueue.main.async {
                    
                    self.graphView.add(accelValue)
                    self.lbl_x.text = String(format: "X: %.2f", accelValue.x)
                    self.lbl_y.text = String(format: "Y: %.2f", accelValue.y)
                    self.lbl_z.text = String(format: "Z: %.2f", accelValue.z)
                }

            
            
        }else{
            
            var gyro:Array<Float> = [0.0, 0.0, 0.0]
            
            gyro[0] = bleValue[3]
            gyro[1] = bleValue[4]
            gyro[2] = bleValue[5]
            
            let gyroValue:SIMD3<Double> = [ Double(gyro[0]), Double(gyro[1]), Double(gyro[2]) ]
            let gyroGraphsValue:SIMD3<Double> = [ Double(gyro[0]) / 3.0, Double(gyro[1]) / 3.0, Double(gyro[2]) / 3.0 ]
            DispatchQueue.main.async {
                
                self.graphView.add(gyroGraphsValue)
                self.lbl_x.text = String(format: "X: %.2f", gyroValue.x)
                self.lbl_y.text = String(format: "Y: %.2f", gyroValue.y)
                self.lbl_z.text = String(format: "Z: %.2f", gyroValue.z)
            }
        }
    }
    
    func peripheral_MPU9250Data(value: NSData) {
        
    }
    
    @objc func notifyList(notification: Notification){
        
        //print("notifyList")
        
        let sensors:Array<AdvPeripheral> = notification.userInfo?["sensor"] as! Array<AdvPeripheral>
        
        DispatchQueue.main.async {
            let listView:ListSeonsorViewController = self.storyboard?.instantiateViewController(withIdentifier: "ListSensorView") as! ListSeonsorViewController
            
            listView.dataSourceList = sensors
            
            let navi:UINavigationController = UINavigationController.init(rootViewController: listView)
            self.present(navi, animated: true, completion: {
                
            })
            
            
        }
        
    }
    
    @objc func notifyListZero(notification: Notification){
        
    }

    
    @IBOutlet weak var lbl_z: UILabel!
    @IBOutlet weak var lbl_y: UILabel!
    @IBOutlet weak var lbl_x: UILabel!
    
    @IBOutlet weak var graphView: GraphView!
    
    var manager:BTManager! = BTManager.shared
    weak var btPeripheral:BT_Peripheral?
    var isAccel:Bool! = true
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
  
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(notifyList(notification:)),
                                               name: NSNotification.Name.init("notifyList"),
                                               object: nil)
        
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(notifyListZero(notification:)),
                                               name: NSNotification.Name.init("notifyZero"),
                                               object: nil)
        
        self.lbl_x.text = "X: 0.00"
        self.lbl_y.text = "Y: 0.00"
        self.lbl_z.text = "Z: 0.00"
        
        manager.delegate = self
        
//        NotificationCenter.default.addObserver(self, selector: #selector(notifyListZero(notification:)), name: .notifyListZero, object: nil)
//        NotificationCenter.default.addObserver(self, selector: #selector(notifyList(notification:)), name: .notifyList, object: nil)
    }
    
    @IBAction func seg_valueChanged(_ sender: Any) {
        isAccel = !isAccel
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
