//
//  AdvPeripheral.swift
//  AbilityTrainer
//
//  Created by hoehoe on 2019/09/04.
//  Copyright © 2019 chocbanana. All rights reserved.
//

import UIKit
import CoreBluetooth

class AdvPeripheral: NSObject {
    /*
     @property (strong, nonatomic) CBPeripheral *peripheral;
     @property (strong, nonatomic) NSNumber* rssi;
     @property (strong, nonatomic) NSString* identifier;
     @property (strong, nonatomic) NSString* name;
     */
    
    var peripheral:CBPeripheral!
    var rssi:NSNumber!
    var identifier:String!
    var name:String!
    
    @objc func comparWithIdentifier(item:AdvPeripheral) -> ComparisonResult {
        //NSComparisonResult result = [self.identifier compare:item.identifier];
        var result:ComparisonResult = self.rssi.compare(item.rssi)
        //var result:ComparisonResult = ComparisonResult(rawValue: self.rssi.intValue)!
        // RSSIの降順でソート
        switch(result){
            case .orderedAscending:
                result = .orderedAscending
                break
            case .orderedSame:
                result = .orderedSame
                break
            case .orderedDescending:
                break
        }
        
        return result;
    }
}
