//
//  GameViewController.swift
//  SC_Box
//
//  Created by hoehoe on 2019/02/27.
//  Copyright © 2019 chocbanana. All rights reserved.
//

import UIKit
import QuartzCore
import SceneKit

class GameViewController: UIViewController, SCNSceneRendererDelegate, BT_ManagerDelegate, BT_PeripheralDelegate{
    
    var manager:BTManager! = BTManager.shared
    weak var btPeripheral:BT_Peripheral?
    var ship:SCNNode!
    
    var label:SCNNode!
    
    var qua:SCNQuaternion! = SCNQuaternion()
    var vec4:SCNVector4!
    var d4:SIMD4<Float> = [0.0, 0.0, 0.0, 0.0];
        
    func sizeof <T> (_ : T.Type) -> Int
    {
        return (MemoryLayout<T>.size)
    }
    
    func sizeof <T> (_ : T) -> Int
    {
        return (MemoryLayout<T>.size)
    }
    
    func sizeof <T> (_ value : [T]) -> Int
    {
        return (MemoryLayout<T>.size * value.count)
    }
    
    func foundPeripheralDelegate(btPeripheral: BT_Peripheral) {
        self.btPeripheral = btPeripheral
        self.btPeripheral?.delegate = self
    }
    
    func lostPeripheralDelegate() {
        self.btPeripheral = nil
    }
    

    func peripheral_Data(value: NSData) {
 
//        var bleValue:Array<Float> = [0.0, 0.0, 0.0, 0.0] //Quaternion
        var bleValue:Array<Float> = [0.0, 0.0, 0.0, //Accel
        0.0, 0.0, 0.0, //Gyro
        0.0, 0.0, 0.0, 0.0] //Quaternion
        
        value.getBytes(&bleValue, range: NSMakeRange(0, sizeof(bleValue)))
        
        // Quaternion
        let q0:Float = bleValue[6]
        let q1:Float = bleValue[7]
        let q2:Float = bleValue[8]
        let q3:Float = bleValue[9]
        
        
//        print("quat: ", q0, q1, q2, q3)
        let d4:SIMD4<Double> = [Double(q0)*50, Double(q1)*50, Double(q2)*50, Double(q3)*50]
        let vec4:SCNVector4 =  SCNVector4(d4)
        self.qua = vec4
        
        DispatchQueue.main.async {
            
            self.ship.runAction(
                SCNAction.rotate(toAxisAngle: self.qua, duration: 0.0)
            )
                        
        }
 
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // create a new scene
        let scene = SCNScene(named: "art.scnassets/box.scn")!
        
        // create and add a camera to the scene
        let cameraNode = SCNNode()
        cameraNode.camera = SCNCamera()
        scene.rootNode.addChildNode(cameraNode)
        
        // place the camera
        cameraNode.position = SCNVector3(x: 0, y: 0, z: 15)
        
        // create and add a light to the scene
        let lightNode = SCNNode()
        lightNode.light = SCNLight()
        lightNode.light!.type = .omni
        lightNode.position = SCNVector3(x: 0, y: 10, z: 10)
        scene.rootNode.addChildNode(lightNode)
        
        // create and add an ambient light to the scene
        let ambientLightNode = SCNNode()
        ambientLightNode.light = SCNLight()
        ambientLightNode.light!.type = .ambient
        ambientLightNode.light!.color = UIColor.darkGray
        scene.rootNode.addChildNode(ambientLightNode)
        
        // retrieve the ship node
        ship = scene.rootNode.childNode(withName: "box", recursively: true)!
        
        // animate the 3d object
        //ship.runAction(SCNAction.repeatForever(SCNAction.rotateBy(x: 0, y: 2, z: 0, duration: 1)))
        
        // retrieve the SCNView
        let scnView = self.view as! SCNView
        
        // set the scene to the view
        scnView.scene = scene
        
        // allows the user to manipulate the camera
        scnView.allowsCameraControl = true
        
        // show statistics such as fps and timing information
        scnView.showsStatistics = true
        
        // configure the view
        scnView.backgroundColor = UIColor.black
        
        scnView.delegate = self
        
        manager.delegate = self
        
    }
    
    override var shouldAutorotate: Bool {
        return true
    }
    
    override var prefersStatusBarHidden: Bool {
        return true
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        if UIDevice.current.userInterfaceIdiom == .phone {
            return .allButUpsideDown
        } else {
            return .all
        }
    }
    
    func renderer(_ renderer: SCNSceneRenderer, didSimulatePhysicsAtTime time: TimeInterval) {
        
    }
    
    
}

